# MBoard Keyboard — Native Android Studio Project
**Package**: `com.munjir.munkey`  
**Application Name**: MBoard Keyboard  
**Theme**: Material 3 DayNight (`Theme.Material3.DayNight.NoActionBar`)

---

## 🛠️ Root Cause of Previous GitHub Actions Build Error

The previous build failed with:
```
resource style/Theme.Material3.DayNight.NoActionBar not found
```

### Root Cause
1. `Theme.Material3.DayNight.NoActionBar` is an XML resource style provided by Google's Material Design Components library (`com.google.android.material:material`).
2. The project's `app/build.gradle.kts` only had Jetpack Compose Material 3 (`androidx.compose.material3:material3`) which is a Compose runtime library, not an Android View XML theme provider.
3. Because `com.google.android.material:material:1.12.0` was absent from `app/build.gradle.kts` dependencies, AAPT2 failed to link the theme during resource linking.

### Changes Implemented
- Added `material = "1.12.0"` and `material = { group = "com.google.android.material", name = "material", version.ref = "material" }` to `gradle/libs.versions.toml`.
- Added `implementation(libs.material)` and `implementation(libs.androidx.appcompat)` to `app/build.gradle.kts`.
- Configured `Theme.MBoardKeyboard` in `app/src/main/res/values/themes.xml` inheriting directly from `Theme.Material3.DayNight.NoActionBar`.
- Added `Theme.MunkeyKeyboard` backward-compatible alias.
- Added full color definitions (`accent_blue`, `ios_key_bg_dark`, etc.) in `colors.xml`.
- Provided official Gradle wrapper scripts (`gradlew`, `gradlew.bat`) and wrapper binary (`gradle-wrapper.jar`) with Gradle 8.10.2.
- Provided pre-configured GitHub Actions CI workflow (`.github/workflows/build-apk.yml`).

---

## 🚀 3 Ways to Build the APK

### 1. Free Cloud Build with GitHub Actions (Easiest, No Android Studio Required)
1. Push this repository to GitHub (or import the exported ZIP into a GitHub repository).
2. Go to the **Actions** tab in your repository.
3. You will see the **Build MBoard Keyboard APK** workflow run automatically.
4. Once completed (~2 minutes), click on the run summary and download the **mboard-keyboard-debug-apk** artifact from the bottom of the page!

### 2. Local Terminal with Gradle Wrapper
Prerequisites: JDK 17+ installed (`java -version`).
```bash
cd android
chmod +x gradlew
./gradlew assembleDebug --stacktrace
```
On Windows:
```cmd
gradlew.bat assembleDebug
```
The output APK is generated at:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

### 3. Android Studio (Ladybug 2024.2+ / Hedgehog / Iguana)
1. Launch Android Studio.
2. Select **Open** and choose the `android/` folder.
3. Wait for Gradle sync to complete.
4. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. In the bottom notification bubble, click **locate** to get `app-debug.apk`.

---

## 📱 Installation & Activation Instructions

### Installing on Device via ADB
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Installing Directly on Phone
1. Transfer `app-debug.apk` to your phone (via USB, Google Drive, WhatsApp, or email).
2. Open the file on your device and tap **Install** (allow "Install unknown apps" if prompted).

### Enabling MBoard Keyboard in Android
1. Open the **MBoard Keyboard** app from your home screen / app drawer.
2. Tap **Step 1: Enable Keyboard** (opens Android System Language & Input settings).
3. Find **MBoard Keyboard** in the list of keyboards and toggle the switch **ON**.
4. Tap **Step 2: Select Active Keyboard** and select **MBoard Keyboard**.
5. Tap inside the **Test Typing Area** at the bottom of the app to verify typing immediately!

---

## ⌨️ Keyboard Features Verification

| Feature | Android IME Status | Web Simulator Status | Notes |
|---|---|---|---|
| English QWERTY Input | ✅ Native Working | ✅ Full Simulation | Standard QWERTY typing with shift and symbols |
| Bangla Avro Phonetic | ✅ Native Working | ✅ Full Simulation | Real-time transliteration (ami → আমি, bangla → বাংলা) |
| Bangla Unicode (National) | ✅ Native Working | ✅ Full Simulation | Full Bengali consonant/vowel layout with shift keys |
| Spacebar Tap (Space) | ✅ Native Working | ✅ Full Simulation | Short tap commits standard space character |
| Spacebar Long-Press Popup | ✅ Native Working | ✅ Full Simulation | Long-press opens language selector; consumes touch without space insertion |
| Dynamic Spacebar Label | ✅ Native Working | ✅ Full Simulation | Shows active mode: "English", "বাংলা (Avro)", or "বাংলা (জাতীয়)" |
| Toolbar - Settings | ✅ Native Working | ✅ Full Simulation | Opens native Android IME settings / onboarding screen |
| Toolbar - Clipboard | ✅ Native Working | ✅ Full Simulation | Reads from Android system ClipboardManager |
| Toolbar - Font Studio | ✅ Native Working | ✅ Full Simulation | Unicode mathematical/decorative script conversion |
| Toolbar - Emoji / Themes | ⚡ Extensible IME | ✅ Full Simulation | Accessible via toolbar hooks and UI views |
