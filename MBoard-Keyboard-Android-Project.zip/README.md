# MBoard Keyboard — Native Android Studio Project
Package: com.munjir.munkey

## Quick Build Instructions
1. Open Android Studio -> File -> Open -> Choose this folder.
2. Wait for Gradle sync to complete.
3. Run `./gradlew assembleDebug` or click Run 'app' in Android Studio.
4. Output APK: app/build/outputs/apk/debug/app-debug.apk
