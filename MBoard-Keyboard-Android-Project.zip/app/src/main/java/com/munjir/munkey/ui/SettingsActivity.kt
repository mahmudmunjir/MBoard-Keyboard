package com.munjir.munkey.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class SettingsActivity : ComponentActivity() {

    companion object {
        const val PREFS_NAME = "mboard_prefs"
        const val KEY_LANGUAGE = "pref_language"
        const val KEY_PHONETIC_ENABLED = "pref_phonetic_enabled"
        const val KEY_THEME = "pref_theme"
        const val KEY_SOUND_ENABLED = "pref_sound_enabled"
        const val KEY_VIBRATION_ENABLED = "pref_vibration_enabled"
        const val KEY_VIBRATION_STRENGTH = "pref_vibration_strength"
        const val KEY_KEYBOARD_HEIGHT = "pref_keyboard_height"
        const val KEY_FONT_STYLE = "pref_font_style"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        setContent {
            MunkeyTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0F172A)
                ) {
                    SettingsScreen(
                        prefs = prefs,
                        onBack = { finish() },
                        onOpenSystemSettings = {
                            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
                        },
                        onSwitchIme = {
                            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                            imm?.showInputMethodPicker()
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    prefs: android.content.SharedPreferences,
    onBack: () -> Unit,
    onOpenSystemSettings: () -> Unit,
    onSwitchIme: () -> Unit
) {
    var language by remember {
        mutableStateOf(prefs.getString(SettingsActivity.KEY_LANGUAGE, "bangla_phonetic") ?: "bangla_phonetic")
    }
    var phoneticEnabled by remember {
        mutableStateOf(prefs.getBoolean(SettingsActivity.KEY_PHONETIC_ENABLED, true))
    }
    var theme by remember {
        mutableStateOf(prefs.getString(SettingsActivity.KEY_THEME, "dark") ?: "dark")
    }
    var soundEnabled by remember {
        mutableStateOf(prefs.getBoolean(SettingsActivity.KEY_SOUND_ENABLED, true))
    }
    var vibrationEnabled by remember {
        mutableStateOf(prefs.getBoolean(SettingsActivity.KEY_VIBRATION_ENABLED, true))
    }
    var vibrationStrength by remember {
        mutableStateOf(prefs.getString(SettingsActivity.KEY_VIBRATION_STRENGTH, "medium") ?: "medium")
    }
    var keyboardHeight by remember {
        mutableStateOf(prefs.getString(SettingsActivity.KEY_KEYBOARD_HEIGHT, "normal") ?: "normal")
    }
    var fontStyle by remember {
        mutableStateOf(prefs.getString(SettingsActivity.KEY_FONT_STYLE, "default") ?: "default")
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "MBoard Settings",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 20.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F172A)
                )
            )
        },
        containerColor = Color(0xFF0F172A)
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Section 1: Language & Phonetic
            item {
                SettingsSection(title = "Language & Input", icon = Icons.Default.Language) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Default Input Mode",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF94A3B8)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            LanguageChip(
                                label = "বাংলা Avro",
                                isSelected = language == "bangla_phonetic",
                                onClick = {
                                    language = "bangla_phonetic"
                                    prefs.edit().putString(SettingsActivity.KEY_LANGUAGE, "bangla_phonetic").apply()
                                },
                                modifier = Modifier.weight(1f)
                            )
                            LanguageChip(
                                label = "বাংলা প্রভাত",
                                isSelected = language == "bangla_unicode",
                                onClick = {
                                    language = "bangla_unicode"
                                    prefs.edit().putString(SettingsActivity.KEY_LANGUAGE, "bangla_unicode").apply()
                                },
                                modifier = Modifier.weight(1f)
                            )
                            LanguageChip(
                                label = "English",
                                isSelected = language == "english",
                                onClick = {
                                    language = "english"
                                    prefs.edit().putString(SettingsActivity.KEY_LANGUAGE, "english").apply()
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        SettingToggleRow(
                            title = "Bangla Phonetic Transliteration",
                            subtitle = "Converts 'ami' to 'আমি', 'bangla' to 'বাংলা'",
                            checked = phoneticEnabled,
                            onCheckedChange = {
                                phoneticEnabled = it
                                prefs.edit().putBoolean(SettingsActivity.KEY_PHONETIC_ENABLED, it).apply()
                            }
                        )
                    }
                }
            }

            // Section 2: Themes & Appearance
            item {
                SettingsSection(title = "Theme & Appearance", icon = Icons.Default.Palette) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "Keyboard Theme",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF94A3B8)
                        )

                        val themes = listOf(
                            Triple("dark", "iOS Dark", Color(0xFF1C1C1E)),
                            Triple("light", "iOS Light", Color(0xFFE5E7EB)),
                            Triple("blue", "Ocean Blue", Color(0xFF0F172A)),
                            Triple("green", "Emerald Green", Color(0xFF064E3B)),
                            Triple("pink", "Rose Pink", Color(0xFF831843)),
                            Triple("purple", "Royal Purple", Color(0xFF3B0764))
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (row in themes.chunked(3)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    for ((themeId, themeName, themeColor) in row) {
                                        ThemeCard(
                                            id = themeId,
                                            name = themeName,
                                            previewColor = themeColor,
                                            isSelected = theme == themeId,
                                            onClick = {
                                                theme = themeId
                                                prefs.edit().putString(SettingsActivity.KEY_THEME, themeId).apply()
                                            },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Keyboard Height",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF94A3B8)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            HeightChip(
                                label = "Compact",
                                isSelected = keyboardHeight == "compact",
                                onClick = {
                                    keyboardHeight = "compact"
                                    prefs.edit().putString(SettingsActivity.KEY_KEYBOARD_HEIGHT, "compact").apply()
                                },
                                modifier = Modifier.weight(1f)
                            )
                            HeightChip(
                                label = "Normal",
                                isSelected = keyboardHeight == "normal",
                                onClick = {
                                    keyboardHeight = "normal"
                                    prefs.edit().putString(SettingsActivity.KEY_KEYBOARD_HEIGHT, "normal").apply()
                                },
                                modifier = Modifier.weight(1f)
                            )
                            HeightChip(
                                label = "Tall",
                                isSelected = keyboardHeight == "tall",
                                onClick = {
                                    keyboardHeight = "tall"
                                    prefs.edit().putString(SettingsActivity.KEY_KEYBOARD_HEIGHT, "tall").apply()
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Font Style Studio",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF94A3B8)
                        )

                        val fontStyles = listOf(
                            Triple("default", "Modern Sans", "আমার সোনার বাংলা • Quick Fox"),
                            Triple("serif", "Classic Serif", "রবীন্দ্রনাথ ঠাকুর • Classic Serif"),
                            Triple("bold", "Bold Impact", "বাংলা বর্ণমালা • Bold Impact"),
                            Triple("monospace", "Monospace", "কম্পিউটার কোড • Monospace 101"),
                            Triple("script", "Cursive Script", "শিল্প ও সংস্কৃতি • Cursive Script"),
                            Triple("rounded", "Soft Rounded", "সহজ সুন্দর বাংলা • Rounded Soft")
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            for ((fId, fName, fPreview) in fontStyles) {
                                val isSelected = fontStyle == fId
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSelected) Color(0xFF334155) else Color(0xFF1E293B))
                                        .border(
                                            width = if (isSelected) 1.5.dp else 0.5.dp,
                                            color = if (isSelected) Color(0xFF38BDF8) else Color(0xFF334155),
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                        .clickable {
                                            fontStyle = fId
                                            prefs.edit().putString(SettingsActivity.KEY_FONT_STYLE, fId).apply()
                                        }
                                        .padding(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = fName,
                                                color = Color.White,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = fPreview,
                                                color = if (isSelected) Color(0xFF93C5FD) else Color(0xFF94A3B8),
                                                fontSize = 12.sp,
                                                maxLines = 1
                                            )
                                        }
                                        if (isSelected) {
                                            Text(
                                                text = "✓",
                                                color = Color(0xFF38BDF8),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 16.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section 3: Sound & Vibration
            item {
                SettingsSection(title = "Sound & Vibration", icon = Icons.Default.VolumeUp) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SettingToggleRow(
                            title = "Keypress Sound",
                            subtitle = "Plays audio click sound on key press",
                            checked = soundEnabled,
                            onCheckedChange = {
                                soundEnabled = it
                                prefs.edit().putBoolean(SettingsActivity.KEY_SOUND_ENABLED, it).apply()
                            }
                        )

                        SettingToggleRow(
                            title = "Keypress Vibration",
                            subtitle = "Haptic feedback when tapping keys",
                            checked = vibrationEnabled,
                            onCheckedChange = {
                                vibrationEnabled = it
                                prefs.edit().putBoolean(SettingsActivity.KEY_VIBRATION_ENABLED, it).apply()
                            }
                        )

                        if (vibrationEnabled) {
                            Text(
                                text = "Vibration Strength",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF94A3B8)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                HeightChip(
                                    label = "Light",
                                    isSelected = vibrationStrength == "light",
                                    onClick = {
                                        vibrationStrength = "light"
                                        prefs.edit().putString(SettingsActivity.KEY_VIBRATION_STRENGTH, "light").apply()
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                                HeightChip(
                                    label = "Medium",
                                    isSelected = vibrationStrength == "medium",
                                    onClick = {
                                        vibrationStrength = "medium"
                                        prefs.edit().putString(SettingsActivity.KEY_VIBRATION_STRENGTH, "medium").apply()
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                                HeightChip(
                                    label = "Strong",
                                    isSelected = vibrationStrength == "strong",
                                    onClick = {
                                        vibrationStrength = "strong"
                                        prefs.edit().putString(SettingsActivity.KEY_VIBRATION_STRENGTH, "strong").apply()
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            // Section 4: System Input Setup
            item {
                SettingsSection(title = "System Setup", icon = Icons.Default.Tune) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = onOpenSystemSettings,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("1. Enable MBoard in System Settings")
                        }

                        OutlinedButton(
                            onClick = onSwitchIme,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF818CF8)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF4F46E5)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Keyboard, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("2. Select MBoard as Active Keyboard")
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun SettingsSection(
    title: String,
    icon: ImageVector,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = Color(0xFF818CF8), modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
            content()
        }
    }
}

@Composable
fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(text = title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(text = subtitle, color = Color(0xFF94A3B8), fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF6366F1),
                uncheckedThumbColor = Color(0xFF94A3B8),
                uncheckedTrackColor = Color(0xFF334155)
            )
        )
    }
}

@Composable
fun LanguageChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) Color(0xFF4F46E5) else Color(0xFF334155))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) Color.White else Color(0xFFCBD5E1),
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 12.sp
        )
    }
}

@Composable
fun HeightChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) Color(0xFF4F46E5) else Color(0xFF334155))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) Color.White else Color(0xFFCBD5E1),
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            fontSize = 12.sp
        )
    }
}

@Composable
fun ThemeCard(
    id: String,
    name: String,
    previewColor: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF334155))
            .border(
                width = if (isSelected) 2.dp else 0.dp,
                color = if (isSelected) Color(0xFF38BDF8) else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(previewColor)
                    .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
            )
            Text(
                text = name,
                color = if (isSelected) Color.White else Color(0xFFCBD5E1),
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                fontSize = 11.sp,
                maxLines = 1
            )
        }
    }
}
