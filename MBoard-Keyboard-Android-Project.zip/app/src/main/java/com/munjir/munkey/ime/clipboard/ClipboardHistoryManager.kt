package com.munjir.munkey.ime.clipboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ClipEntry(
    val id: String,
    val text: String,
    val timestamp: Long
)

object ClipboardHistoryManager {
    private const val PREFS_NAME = "mboard_clipboard"
    private const val KEY_HISTORY = "clip_history_json"
    private const val MAX_ITEMS = 25

    fun getClips(context: Context): List<ClipEntry> {
        val sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = sp.getString(KEY_HISTORY, null) ?: return emptyList()
        val list = mutableListOf<ClipEntry>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    ClipEntry(
                        id = obj.getString("id"),
                        text = obj.getString("text"),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    fun syncFromSystemClipboard(context: Context) {
        val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
        val clip = cb.primaryClip ?: return
        if (clip.itemCount > 0) {
            val text = clip.getItemAt(0).text?.toString()
            if (!text.isNullOrBlank()) {
                addClip(context, text)
            }
        }
    }

    fun addClip(context: Context, text: String) {
        if (text.isBlank()) return
        val current = getClips(context).toMutableList()
        // Deduplicate
        current.removeAll { it.text.trim() == text.trim() }
        val entry = ClipEntry(
            id = "clip_${System.currentTimeMillis()}",
            text = text,
            timestamp = System.currentTimeMillis()
        )
        current.add(0, entry)
        if (current.size > MAX_ITEMS) {
            current.removeAt(current.size - 1)
        }
        saveClips(context, current)
    }

    fun deleteClip(context: Context, id: String) {
        val current = getClips(context).toMutableList()
        current.removeAll { it.id == id }
        saveClips(context, current)
    }

    fun clearAll(context: Context) {
        saveClips(context, emptyList())
    }

    private fun saveClips(context: Context, list: List<ClipEntry>) {
        val sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("text", item.text)
                put("timestamp", item.timestamp)
            }
            array.put(obj)
        }
        sp.edit().putString(KEY_HISTORY, array.toString()).apply()
    }
}
