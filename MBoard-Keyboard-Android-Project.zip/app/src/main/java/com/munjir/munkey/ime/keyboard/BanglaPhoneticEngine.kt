package com.munjir.munkey.ime.keyboard

object BanglaPhoneticEngine {
    private val commonWords = mapOf(
        "ami" to "আমি", "amar" to "আমার", "bangla" to "বাংলা", "tumi" to "তুমি",
        "kemon" to "কেমন", "acho" to "আছো", "achho" to "আছো", "dhonnobad" to "ধন্যবাদ",
        "bhalobashi" to "ভালোবাসি", "valobashi" to "ভালোবাসি", "bhalobasi" to "ভালোবাসি", "valobasi" to "ভালোবাসি",
        "apni" to "আপনি", "apnar" to "আপনার", "tomar" to "তোমার", "amra" to "আমরা",
        "amader" to "আমাদের", "tomra" to "তোমরা", "tader" to "তাদের", "se" to "সে",
        "tar" to "তার", "taar" to "তার", "ini" to "ইনি", "uni" to "উনি", "tini" to "তিনি",
        "shobai" to "সবাই", "bhalo" to "ভালো", "thako" to "থাকো", "ashbo" to "আসবো",
        "ashchi" to "আসছি", "jabo" to "যাবো", "korbo" to "করবো", "korchi" to "করছি",
        "kore" to "করে", "dekha" to "দেখা", "shona" to "শোনা", "bhalobasa" to "ভালোবাসা",
        "ki" to "কী", "keno" to "কেন", "kobe" to "কবে", "kothay" to "কোথায়",
        "koto" to "কত", "kokhon" to "কখন", "ekhon" to "এখন", "shob" to "সব",
        "ha" to "হ্যাঁ", "na" to "না", "ar" to "আর", "aro" to "আরো", "ebong" to "এবং",
        "bangladesh" to "বাংলাদেশ", "dhaka" to "ঢাকা", "desh" to "দেশ", "shonar" to "সোনার",
        "manush" to "মানুষ", "bondhu" to "বন্ধু", "shundor" to "সুন্দর", "shomoy" to "সময়",
        "kolom" to "কলম", "boi" to "বই", "kotha" to "কথা", "kaj" to "কাজ", "gaan" to "গান",
        "shikkha" to "শিক্ষা", "porikkha" to "পরীক্ষা", "shanti" to "শান্তি", "pran" to "প্রাণ",
        "prothom" to "প্রথম", "gram" to "গ্রাম", "jibon" to "জীবন", "mboard" to "এমবোর্ড", "keyboard" to "কীবোর্ড"
    )

    fun transliterate(input: String): String {
        if (input.isEmpty()) return ""
        val lower = input.lowercase()
        return commonWords[lower] ?: input
    }
}
