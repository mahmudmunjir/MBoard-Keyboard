package com.munjir.munkey.ime.keyboard

/**
 * MBoard Keyboard — Native Android Bangla Phonetic Engine
 * Fast dictionary lookup + Avro-style contextual rule-based transliteration.
 */
object BanglaPhoneticEngine {

    // Common full words and idiomatic expressions
    private val commonWords = mapOf(
        // Required core test cases
        "ami" to "আমি",
        "amar" to "আমার",
        "bangla" to "বাংলা",
        "tumi" to "তুমি",
        "kemon" to "কেমন",
        "acho" to "আছো",
        "achho" to "আছো",
        "dhonnobad" to "ধন্যবাদ",
        "bhalobashi" to "ভালোবাসি",
        "valobashi" to "ভালোবাসি",
        "bhalobasi" to "ভালোবাসি",
        "valobasi" to "ভালোবাসি",

        // Pronouns
        "apni" to "আপনি",
        "apnar" to "আপনার",
        "tomar" to "তোমার",
        "amra" to "আমরা",
        "amader" to "আমাদের",
        "tomra" to "তোমরা",
        "tader" to "তাদের",
        "tara" to "তারা",
        "se" to "সে",
        "tar" to "তার",
        "taar" to "তার",
        "ini" to "ইনি",
        "uni" to "উনি",
        "tini" to "তিনি",
        "ora" to "ওরা",
        "era" to "এরা",
        "ke" to "কে",
        "kara" to "কারা",
        "kake" to "কাকে",
        "kar" to "কার",
        "shobai" to "সবাই",
        "sobai" to "সবাই",
        "shobar" to "সবার",

        // Common verbs & greetings
        "achhi" to "আছি",
        "achi" to "আছি",
        "achhen" to "আছেন",
        "achen" to "আছেন",
        "bhalo" to "ভালো",
        "valo" to "ভালো",
        "thako" to "থাকো",
        "thakben" to "থাকবেন",
        "ashbo" to "আসবো",
        "ashchi" to "আসছি",
        "elo" to "এলো",
        "jabo" to "যাবো",
        "jay" to "যায়",
        "korbo" to "করবো",
        "korchi" to "করছি",
        "kore" to "করে",
        "kori" to "করি",
        "koro" to "করো",
        "dekha" to "দেখা",
        "dekhi" to "দেখি",
        "shona" to "শোনা",
        "shunte" to "শুনতে",
        "bhalobasa" to "ভালোবাসা",
        "hobe" to "হবে",
        "holo" to "হলো",

        // Questions & adverbs
        "ki" to "কী",
        "keno" to "কেন",
        "kobe" to "কবে",
        "kothay" to "কোথায়",
        "kivabe" to "কীভাবে",
        "kibhabe" to "কীভাবে",
        "koto" to "কত",
        "kon" to "কোন",
        "kokhon" to "কখন",
        "tokhon" to "তখন",
        "ekhon" to "এখন",
        "shob" to "সব",
        "sob" to "সব",
        "ha" to "হ্যাঁ",
        "na" to "না",
        "aro" to "আরো",
        "ar" to "আর",
        "ebong" to "এবং",
        "karon" to "কারণ",
        "jodi" to "যদি",
        "kintu" to "কিন্তু",

        // Nouns & Places
        "bangladesh" to "বাংলাদেশ",
        "dhaka" to "ঢাকা",
        "desh" to "দেশ",
        "shonar" to "সোনার",
        "sonar" to "সোনার",
        "manush" to "মানুষ",
        "bondhu" to "বন্ধু",
        "shundor" to "সুন্দর",
        "shomoy" to "সময়",
        "kolom" to "কলম",
        "boi" to "বই",
        "kotha" to "কথা",
        "kaj" to "কাজ",
        "gaan" to "গান",
        "gan" to "গান",
        "gai" to "গাই",
        "khabar" to "খাবার",
        "pani" to "পানি",
        "bari" to "বাড়ি",
        "basha" to "বাসা",
        "shikkha" to "শিক্ষা",
        "porikkha" to "পরীক্ষা",
        "shanti" to "শান্তি",
        "pran" to "প্রাণ",
        "prothom" to "প্রথম",
        "gram" to "গ্রাম",
        "jibon" to "জীবন",
        "mboard" to "এমবোর্ড",
        "keyboard" to "কীবোর্ড"
    )

    private val dualConjuncts = mapOf(
        "nd" to "ন্দ",
        "nt" to "ন্ত",
        "mp" to "ম্প",
        "mb" to "ম্ব",
        "kt" to "ক্ত",
        "pt" to "প্ত",
        "bd" to "ব্দ",
        "st" to "স্ত",
        "sp" to "স্প",
        "sk" to "স্ক",
        "tr" to "ত্র",
        "dr" to "দ্র",
        "gr" to "গ্র",
        "pr" to "প্র",
        "br" to "ব্র",
        "kr" to "ক্র",
        "mr" to "ম্র",
        "sr" to "স্র"
    )

    private val multiConsonants = listOf(
        "kkhy" to "ক্ষ্য",
        "kkh" to "ক্ষ",
        "ggh" to "জ্ঞ",
        "cchh" to "চ্ছ্ব",
        "cch" to "চ্ছ",
        "shth" to "ষ্ঠ",
        "shc" to "শ্চ",
        "sht" to "ষ্ট",
        "ddh" to "দ্ধ",
        "gdh" to "গ্ধ",
        "mbh" to "ম্ভ",
        "ng" to "ঙ",
        "ny" to "ঞ",
        "kh" to "খ",
        "gh" to "ঘ",
        "chh" to "চ্ছ",
        "ch" to "ছ",
        "jh" to "ঝ",
        "th" to "থ",
        "Th" to "ঠ",
        "dh" to "ধ",
        "Dh" to "ঢ",
        "ph" to "ফ",
        "bh" to "ভ",
        "sh" to "শ",
        "Sh" to "ষ",
        "shh" to "শ্হ",
        "rh" to "ঢ়",
        "rr" to "ড়"
    )

    private val singleConsonants = mapOf(
        'k' to "ক", 'K' to "খ",
        'g' to "গ", 'G' to "ঘ",
        'c' to "চ", 'C' to "ছ",
        'j' to "জ", 'J' to "ঝ",
        't' to "ত", 'T' to "ট",
        'd' to "দ", 'D' to "ড",
        'n' to "ন", 'N' to "ণ",
        'p' to "প", 'P' to "ফ",
        'f' to "ফ", 'F' to "ফ",
        'b' to "ব", 'B' to "ভ",
        'v' to "ভ", 'V' to "ভ",
        'm' to "ম", 'M' to "ম",
        'r' to "র", 'R' to "ড়",
        'l' to "ল", 'L' to "ল",
        's' to "স", 'S' to "ষ",
        'h' to "হ", 'H' to "হ",
        'y' to "য়", 'Y' to "য",
        'w' to "ও", 'W' to "ও",
        'z' to "য", 'Z' to "য"
    )

    private val independentVowels = mapOf(
        "a" to "আ",
        "aa" to "আ",
        "i" to "ই",
        "ee" to "ঈ",
        "u" to "উ",
        "oo" to "ঊ",
        "rri" to "ঋ",
        "e" to "এ",
        "oi" to "ঐ",
        "o" to "ও",
        "ou" to "ঔ"
    )

    private val vowelKars = mapOf(
        "a" to "া",
        "aa" to "া",
        "i" to "ি",
        "ee" to "ী",
        "u" to "ু",
        "oo" to "ূ",
        "e" to "ে",
        "oi" to "ৈ",
        "o" to "ো",
        "ou" to "ৌ"
    )

    /**
     * Transliterates a token from phonetic English into Bengali.
     */
    fun transliterate(input: String): String {
        if (input.isEmpty()) return ""
        val lower = input.lowercase()
        if (commonWords.containsKey(lower)) {
            return commonWords[lower]!!
        }

        // Handle initial 'a' heuristic (ami, amar, acho, etc.)
        val startsWithA = lower.startsWith("a") && lower.length > 2 &&
                !lower.startsWith("aa") && !lower.startsWith("on") && !lower.startsWith("ob") &&
                "bcdfghjklmnpqrstvwxyz".contains(lower[1]) &&
                "aeiou".contains(lower[2])

        val result = StringBuilder()
        var i = 0
        var isAfterConsonant = false

        while (i < input.length) {
            if (i == 0 && startsWithA) {
                result.append("আ")
                i++
                isAfterConsonant = false
                continue
            }

            // Check dual consonant conjuncts
            if (i + 1 < input.length) {
                val dual = input.substring(i, i + 2).lowercase()
                if (dualConjuncts.containsKey(dual)) {
                    result.append(dualConjuncts[dual])
                    i += 2
                    isAfterConsonant = true
                    continue
                }
            }

            // Check multi-consonants
            var matchedConsonant: String? = null
            var matchLen = 0
            for ((pattern, bangla) in multiConsonants) {
                if (input.regionMatches(i, pattern, 0, pattern.length, ignoreCase = true)) {
                    matchedConsonant = bangla
                    matchLen = pattern.length
                    break
                }
            }

            if (matchedConsonant != null) {
                if (input.regionMatches(i, "ng", 0, 2, ignoreCase = true)) {
                    val nextChar = if (i + 2 < input.length) input[i + 2].lowercaseChar() else null
                    if (nextChar == null || !"aeiou".contains(nextChar)) {
                        matchedConsonant = "ং"
                    }
                }
                result.append(matchedConsonant)
                i += matchLen
                isAfterConsonant = true
                continue
            }

            // Check single consonant
            val ch = input[i]
            if (singleConsonants.containsKey(ch)) {
                result.append(singleConsonants[ch])
                i++
                isAfterConsonant = true
                continue
            }

            // Check vowels
            var matchedVowelKar: String? = null
            var matchedIndepVowel: String? = null
            var vowelLen = 0
            if (i + 1 < input.length) {
                val pair = input.substring(i, i + 2).lowercase()
                if (vowelKars.containsKey(pair)) {
                    matchedVowelKar = vowelKars[pair]
                    matchedIndepVowel = independentVowels[pair]
                    vowelLen = 2
                }
            }

            if (matchedVowelKar == null) {
                val single = input[i].toString().lowercase()
                if (vowelKars.containsKey(single)) {
                    matchedVowelKar = vowelKars[single]
                    matchedIndepVowel = independentVowels[single]
                    vowelLen = 1
                }
            }

            if (matchedVowelKar != null) {
                if (isAfterConsonant) {
                    val vStr = input.substring(i, i + vowelLen).lowercase()
                    if (vStr == "a" && vowelLen == 1) {
                        val isAtEnd = i + vowelLen >= input.length
                        val nextIsConsonant = i + vowelLen < input.length && "bcdfghjklmnpqrstvwxyz".contains(input[i + vowelLen].lowercaseChar())
                        if (isAtEnd || nextIsConsonant) {
                            result.append("া")
                        }
                    } else {
                        result.append(matchedVowelKar)
                    }
                } else {
                    result.append(matchedIndepVowel ?: matchedVowelKar)
                }
                i += vowelLen
                isAfterConsonant = false
                continue
            }

            // Numbers & punctuation
            when (ch) {
                '0' -> result.append('০')
                '1' -> result.append('১')
                '2' -> result.append('২')
                '3' -> result.append('৩')
                '4' -> result.append('৪')
                '5' -> result.append('৫')
                '6' -> result.append('৬')
                '7' -> result.append('৭')
                '8' -> result.append('৮')
                '9' -> result.append('৯')
                '.' -> result.append('।')
                else -> result.append(ch)
            }
            isAfterConsonant = false
            i++
        }
        return result.toString()
    }
}
