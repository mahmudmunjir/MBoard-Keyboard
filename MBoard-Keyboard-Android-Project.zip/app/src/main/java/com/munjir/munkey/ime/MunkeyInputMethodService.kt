package com.munjir.munkey.ime

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.munjir.munkey.ime.fontstudio.UnicodeFontConverter
import com.munjir.munkey.ime.keyboard.BanglaPhoneticEngine
import com.munjir.munkey.ime.keyboard.KeyboardLayouts
import com.munjir.munkey.ime.keyboard.KeyboardMode

class MunkeyInputMethodService : InputMethodService() {
    private var currentMode = KeyboardMode.BANGLA_PHONETIC
    private var isShifted = false
    private var isCapsLocked = false
    private var currentFontStyle = UnicodeFontConverter.FontStyle.NORMAL
    private val phoneticBuffer = StringBuilder()
    private var vibrator: Vibrator? = null
    private var audioManager: AudioManager? = null

    private var rootLayout: FrameLayout? = null
    private var keyboardContainer: LinearLayout? = null
    private var suggestionContainer: LinearLayout? = null
    private var languageOverlay: FrameLayout? = null

    private var bgKeyboardColor = 0xFF1C1C1E.toInt()
    private var bgToolbarColor = 0xFF2C2C2E.toInt()
    private var bgKeyNormalColor = 0xFF636366.toInt()
    private var bgKeySpecialColor = 0xFF48484A.toInt()
    private var bgKeyAccentColor = 0xFF0A84FF.toInt()
    private var keyTextColor = 0xFFFFFFFF.toInt()

    override fun onCreate() {
        super.onCreate()
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    override fun onCreateInputView(): View {
        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setBackgroundColor(bgKeyboardColor)
        }
        rootLayout = root

        val mainContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        // 1. Redesigned 6-tool Toolbar (no upper language buttons)
        val toolbar = createToolbar()
        mainContent.addView(toolbar)

        // 2. Candidate / Suggestion Strip
        val sugStrip = createSuggestionStrip()
        mainContent.addView(sugStrip)

        // 3. Main Keyboard Keys Container
        val rowsLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        keyboardContainer = rowsLayout
        mainContent.addView(rowsLayout)
        root.addView(mainContent)

        // 4. In-Window Language Selection Popup Overlay
        val overlay = createLanguageMenuOverlay()
        languageOverlay = overlay
        root.addView(overlay)

        refreshKeyboardLayout()
        return root
    }

    private fun createToolbar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(bgToolbarColor)
            gravity = Gravity.CENTER_VERTICAL
            weightSum = 6.0f
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        bar.addView(createToolbarButton("𝔉", "Fonts", 0xFF0A84FF.toInt()) { toggleFontStyle() })
        bar.addView(createToolbarButton("😊", "Emoji", 0xFFFFD60A.toInt()) { currentInputConnection?.commitText("😊", 1) })
        bar.addView(createToolbarButton("🖼️", "Stickers", 0xFFFF375F.toInt()) { currentInputConnection?.commitText("✨", 1) })
        bar.addView(createToolbarButton("📋", "Clipboard", 0xFF30D158.toInt()) { pasteFromClipboard() })
        bar.addView(createToolbarButton("🎨", "Themes", 0xFF64D2FF.toInt()) { cycleKeyboardTheme() })
        bar.addView(createToolbarButton("⚙️", "Settings", 0xFFFF9F0A.toInt()) { openSettingsActivity() })
        return bar
    }

    private fun createToolbarButton(icon: String, label: String, tintColor: Int, onClick: () -> Unit): View {
        val frame = FrameLayout(this).apply {
            val params = LinearLayout.LayoutParams(0, dpToPx(38), 1.0f).apply {
                setMargins(dpToPx(2), 0, dpToPx(2), 0)
            }
            layoutParams = params
        }
        val btn = TextView(this).apply {
            text = icon
            contentDescription = label
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(tintColor)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(10).toFloat()
                setColor(0x1AFFFFFF)
            }
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setOnClickListener {
                provideFeedback()
                onClick()
            }
        }
        frame.addView(btn)
        return frame
    }

    private fun createSuggestionStrip(): View {
        val strip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 6, 12, 6)
            setBackgroundColor(0xFF242426.toInt())
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(36))
        }
        suggestionContainer = strip
        updateSuggestionStrip()
        return strip
    }

    private fun updateSuggestionStrip() {
        val container = suggestionContainer ?: return
        container.removeAllViews()
        if (currentMode == KeyboardMode.BANGLA_PHONETIC && phoneticBuffer.isNotEmpty()) {
            val bangla = BanglaPhoneticEngine.transliterate(phoneticBuffer.toString())
            val candidateBtn = TextView(this).apply {
                text = bangla
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 15f
                setTypeface(null, Typeface.BOLD)
                background = GradientDrawable().apply {
                    cornerRadius = dpToPx(8).toFloat()
                    setColor(0xFF0A84FF.toInt())
                }
                setPadding(dpToPx(12), dpToPx(4), dpToPx(12), dpToPx(4))
                setOnClickListener {
                    provideFeedback()
                    flushPhoneticBuffer()
                    currentInputConnection?.commitText(" ", 1)
                }
            }
            container.addView(candidateBtn)

            val rawEnglishBtn = TextView(this).apply {
                text = "\"${phoneticBuffer}\""
                setTextColor(0xFF0A84FF.toInt())
                textSize = 13f
                setPadding(dpToPx(12), dpToPx(4), dpToPx(12), dpToPx(4))
                setOnClickListener {
                    provideFeedback()
                    currentInputConnection?.commitText("${phoneticBuffer} ", 1)
                    phoneticBuffer.clear()
                    updateSuggestionStrip()
                }
            }
            container.addView(rawEnglishBtn)
        } else {
            val statusHint = TextView(this).apply {
                text = when (currentMode) {
                    KeyboardMode.BANGLA_PHONETIC -> "বাংলা Phonetic: Type English phonetically (ami, bangla)"
                    KeyboardMode.BANGLA_UNICODE -> "বাংলা Unicode Layout active"
                    else -> "English (US) QWERTY active"
                }
                setTextColor(0xFF8E8E93.toInt())
                textSize = 11f
            }
            container.addView(statusHint)
        }
    }

    private fun createLanguageMenuOverlay(): FrameLayout {
        val overlay = FrameLayout(this).apply {
            setBackgroundColor(0x99000000.toInt())
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setOnClickListener { hideLanguageMenu() }
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dpToPx(16).toFloat()
                setColor(0xFF2C2C2E.toInt())
                setStroke(dpToPx(1), 0xFF3A3A3C.toInt())
            }
            setPadding(dpToPx(16), dpToPx(14), dpToPx(16), dpToPx(14))
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                setMargins(dpToPx(16), 0, dpToPx(16), dpToPx(12))
            }
            setOnClickListener { }
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dpToPx(10)
            }
        }
        val title = TextView(this).apply {
            text = "🌐 Select Input Language"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f)
        }
        titleRow.addView(title)
        val closeBtn = TextView(this).apply {
            text = "✕"
            setTextColor(0xFF8E8E93.toInt())
            textSize = 16f
            setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4))
            setOnClickListener { hideLanguageMenu() }
        }
        titleRow.addView(closeBtn)
        card.addView(titleRow)

        card.addView(createLanguageOptionView("🇺🇸", "English QWERTY", "Standard English typing • Font Style Studio", currentMode == KeyboardMode.ENGLISH, KeyboardMode.ENGLISH))
        card.addView(createLanguageOptionView("🇧🇩", "বাংলা Phonetic (Avro-style)", "Type Roman letters (ami, bangla) → Bengali", currentMode == KeyboardMode.BANGLA_PHONETIC, KeyboardMode.BANGLA_PHONETIC))
        card.addView(createLanguageOptionView("⌨️", "বাংলা Unicode (National/Probhat)", "Traditional Bengali keyboard with shift toggle", currentMode == KeyboardMode.BANGLA_UNICODE, KeyboardMode.BANGLA_UNICODE))

        overlay.addView(card)
        return overlay
    }

    private fun createLanguageOptionView(flag: String, name: String, desc: String, isSelected: Boolean, targetMode: KeyboardMode): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dpToPx(10).toFloat()
                if (isSelected) setColor(0xFF0A84FF.toInt()) else { setColor(0xFF1C1C1E.toInt()); setStroke(dpToPx(1), 0xFF38383A.toInt()) }
            }
            setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dpToPx(6)
            }
            setOnClickListener {
                provideFeedback()
                selectLanguage(targetMode)
            }
        }
        row.addView(TextView(this).apply { text = flag; textSize = 20f; setPadding(0, 0, dpToPx(10), 0) })
        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f)
        }
        textCol.addView(TextView(this).apply { text = name; setTextColor(0xFFFFFFFF.toInt()); textSize = 14f; setTypeface(null, Typeface.BOLD) })
        textCol.addView(TextView(this).apply { text = desc; setTextColor(if (isSelected) 0xFFD0E6FF.toInt() else 0xFF8E8E93.toInt()); textSize = 11f })
        row.addView(textCol)
        if (isSelected) {
            row.addView(TextView(this).apply { text = "✓"; setTextColor(0xFFFFFFFF.toInt()); textSize = 16f; setTypeface(null, Typeface.BOLD); setPadding(dpToPx(6), 0, 0, 0) })
        }
        return row
    }

    private fun showLanguageMenu() {
        rootLayout?.let { root ->
            languageOverlay?.let { root.removeView(it) }
            val newOverlay = createLanguageMenuOverlay()
            languageOverlay = newOverlay
            root.addView(newOverlay)
            newOverlay.visibility = View.VISIBLE
        }
    }

    private fun hideLanguageMenu() {
        languageOverlay?.visibility = View.GONE
    }

    private fun selectLanguage(newMode: KeyboardMode) {
        flushPhoneticBuffer()
        currentMode = newMode
        hideLanguageMenu()
        refreshKeyboardLayout()
        updateSuggestionStrip()
    }

    private fun getSpacebarLabel(): String {
        return when (currentMode) {
            KeyboardMode.BANGLA_PHONETIC -> "space • বাংলা (Avro)"
            KeyboardMode.BANGLA_UNICODE -> "স্পেস • বাংলা (National)"
            KeyboardMode.ENGLISH -> "space • English (US)"
            KeyboardMode.NUMBERS, KeyboardMode.SYMBOLS -> "space"
        }
    }

    private fun refreshKeyboardLayout() {
        val container = keyboardContainer ?: return
        container.removeAllViews()
        val rows = when (currentMode) {
            KeyboardMode.ENGLISH, KeyboardMode.BANGLA_PHONETIC -> KeyboardLayouts.englishRows
            KeyboardMode.BANGLA_UNICODE -> if (isShifted) KeyboardLayouts.banglaUnicodeShiftRows else KeyboardLayouts.banglaUnicodeRows
            KeyboardMode.NUMBERS -> KeyboardLayouts.numberRows
            KeyboardMode.SYMBOLS -> KeyboardLayouts.symbolRows
        }
        for (row in rows) {
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dpToPx(3), dpToPx(3), dpToPx(3), dpToPx(3))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
            for (key in row) {
                rowLayout.addView(createKeyView(key))
            }
            container.addView(rowLayout)
        }
    }

    private fun createKeyView(key: String): View {
        val isSpecial = key in listOf("shift", "backspace", "?123", "symbols", "numbers", "ABC", "globe", "enter")
        val isSpace = (key == "space")

        return Button(this).apply {
            val weight = when (key) {
                "space" -> 4.5f
                "enter", "shift", "backspace" -> 1.4f
                "?123", "symbols", "numbers", "ABC" -> 1.3f
                "globe" -> 1.0f
                else -> 1.0f
            }
            background = GradientDrawable().apply {
                cornerRadius = dpToPx(8).toFloat()
                when {
                    key == "enter" -> setColor(bgKeyAccentColor)
                    isSpecial -> setColor(bgKeySpecialColor)
                    else -> setColor(bgKeyNormalColor)
                }
            }
            setTextColor(keyTextColor)
            textSize = when {
                isSpace -> 12f
                isSpecial -> 13f
                else -> 17f
            }
            text = when (key) {
                "shift" -> if (isShifted) "⬆" else "⇧"
                "backspace" -> "⌫"
                "enter" -> "↵"
                "globe" -> "🌐"
                "space" -> getSpacebarLabel()
                else -> if (currentMode == KeyboardMode.ENGLISH && isShifted) key.uppercase() else key
            }
            layoutParams = LinearLayout.LayoutParams(0, dpToPx(46), weight).apply {
                setMargins(dpToPx(2), dpToPx(3), dpToPx(2), dpToPx(3))
            }

            if (isSpace) {
                // Long-press Spacebar: Opens language popup without inserting space
                setOnLongClickListener {
                    provideFeedback(isLong = true)
                    showLanguageMenu()
                    true
                }
                // Short tap: inserts single space
                setOnClickListener { onKeyTapped("space") }
            } else if (key == "globe") {
                setOnClickListener {
                    provideFeedback()
                    showLanguageMenu()
                }
            } else {
                setOnClickListener { onKeyTapped(key) }
            }
        }
    }

    private fun onKeyTapped(key: String) {
        provideFeedback()
        val ic = currentInputConnection ?: return
        when (key) {
            "shift" -> {
                isShifted = !isShifted
                refreshKeyboardLayout()
            }
            "backspace" -> {
                if (currentMode == KeyboardMode.BANGLA_PHONETIC && phoneticBuffer.isNotEmpty()) {
                    phoneticBuffer.deleteCharAt(phoneticBuffer.length - 1)
                    val bangla = BanglaPhoneticEngine.transliterate(phoneticBuffer.toString())
                    ic.setComposingText(bangla, 1)
                    updateSuggestionStrip()
                } else {
                    ic.deleteSurroundingText(1, 0)
                }
            }
            "enter" -> {
                flushPhoneticBuffer()
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
            }
            "space" -> {
                flushPhoneticBuffer()
                ic.commitText(" ", 1)
                updateSuggestionStrip()
            }
            "?123" -> { currentMode = KeyboardMode.NUMBERS; refreshKeyboardLayout() }
            "ABC" -> { currentMode = KeyboardMode.ENGLISH; refreshKeyboardLayout() }
            "symbols" -> { currentMode = KeyboardMode.SYMBOLS; refreshKeyboardLayout() }
            "numbers" -> { currentMode = KeyboardMode.NUMBERS; refreshKeyboardLayout() }
            "globe" -> showLanguageMenu()
            else -> {
                var charToCommit = if (isShifted && currentMode == KeyboardMode.ENGLISH) key.uppercase() else key
                if (currentMode == KeyboardMode.BANGLA_PHONETIC) {
                    phoneticBuffer.append(charToCommit)
                    val bangla = BanglaPhoneticEngine.transliterate(phoneticBuffer.toString())
                    ic.setComposingText(bangla, 1)
                    updateSuggestionStrip()
                } else {
                    if (currentFontStyle != UnicodeFontConverter.FontStyle.NORMAL && currentMode == KeyboardMode.ENGLISH) {
                        charToCommit = UnicodeFontConverter.convert(charToCommit, currentFontStyle)
                    }
                    ic.commitText(charToCommit, 1)
                    if (isShifted && !isCapsLocked) {
                        isShifted = false
                        refreshKeyboardLayout()
                    }
                }
            }
        }
    }

    private fun flushPhoneticBuffer() {
        if (phoneticBuffer.isNotEmpty()) {
            val bangla = BanglaPhoneticEngine.transliterate(phoneticBuffer.toString())
            currentInputConnection?.commitText(bangla, 1)
            phoneticBuffer.clear()
        }
    }

    private fun toggleFontStyle() {
        val styles = UnicodeFontConverter.FontStyle.values()
        val nextIdx = (currentFontStyle.ordinal + 1) % styles.size
        currentFontStyle = styles[nextIdx]
    }

    private fun pasteFromClipboard() {
        val cb = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val clip = cb?.primaryClip
        if (clip != null && clip.itemCount > 0) {
            val text = clip.getItemAt(0).text
            if (!text.isNullOrEmpty()) {
                currentInputConnection?.commitText(text, 1)
            }
        }
    }

    private fun cycleKeyboardTheme() {
        if (bgKeyboardColor == 0xFF1C1C1E.toInt()) {
            bgKeyboardColor = 0xFFD1D5DB.toInt()
            bgToolbarColor = 0xFFE5E7EB.toInt()
            bgKeyNormalColor = 0xFFFFFFFF.toInt()
            bgKeySpecialColor = 0xFFB0B5BD.toInt()
            keyTextColor = 0xFF000000.toInt()
        } else {
            bgKeyboardColor = 0xFF1C1C1E.toInt()
            bgToolbarColor = 0xFF2C2C2E.toInt()
            bgKeyNormalColor = 0xFF636366.toInt()
            bgKeySpecialColor = 0xFF48484A.toInt()
            keyTextColor = 0xFFFFFFFF.toInt()
        }
        rootLayout?.setBackgroundColor(bgKeyboardColor)
        suggestionContainer?.setBackgroundColor(bgToolbarColor)
        refreshKeyboardLayout()
    }

    private fun openSettingsActivity() {
        try {
            val intent = Intent(this, com.munjir.munkey.ui.MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: Exception) {}
    }

    private fun provideFeedback(isLong: Boolean = false) {
        try {
            audioManager?.playSoundEffect(AudioManager.FX_KEY_CLICK)
            val duration = if (isLong) 28L else 12L
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(duration)
            }
        } catch (_: Exception) {}
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), resources.displayMetrics).toInt()
    }
}
