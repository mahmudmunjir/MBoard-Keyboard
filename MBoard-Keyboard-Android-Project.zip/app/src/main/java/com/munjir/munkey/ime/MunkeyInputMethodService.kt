package com.munjir.munkey.ime

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.munjir.munkey.ime.clipboard.ClipboardHistoryManager
import com.munjir.munkey.ime.fontstudio.UnicodeFontConverter
import com.munjir.munkey.ime.keyboard.BanglaPhoneticEngine
import com.munjir.munkey.ime.keyboard.KeyboardLayouts
import com.munjir.munkey.ime.keyboard.KeyboardMode
import com.munjir.munkey.ime.sticker.StickerItem
import com.munjir.munkey.ime.sticker.StickerManager
import com.munjir.munkey.ui.SettingsActivity
import com.munjir.munkey.ui.StickerImportActivity
import java.io.File

/**
 * MBoard Keyboard - Gboard-Level Native Android InputMethodService
 * Features:
 * 1. Sticker Studio: Local rich content sharing via FileProvider & InputConnectionCompat.commitContent()
 * 2. High-Performance Bangla Phonetic Engine: Zero view-recreation lag & safe spacebar commits
 * 3. Complete Unicode Emoji Panel: 9 standard categories with instant insertion
 * 4. Clipboard Manager: Recent copy history with tap-to-paste and clearing
 * 5. Font Style Studio: 6 selectable styles that visibly style Bangla & English key labels
 * 6. Theme Engine: 6 distinct high-contrast themes with live application & persistence
 * 7. System Insets & Inset-safe Navigation: Separate Back/Hide and Android IME switcher controls
 * 8. Safe Unicode Backspace with continuous hold-to-repeat
 */
class MunkeyInputMethodService : InputMethodService() {

    enum class PanelViewMode {
        KEYBOARD,
        EMOJI,
        THEMES,
        FONTS,
        STICKERS,
        CLIPBOARD
    }

    data class KeyboardThemeData(
        val id: String,
        val name: String,
        val bgKeyboard: Int,
        val bgToolbar: Int,
        val bgSuggestion: Int,
        val bgKeyNormal: Int,
        val bgKeySpecial: Int,
        val bgKeyAccent: Int,
        val keyText: Int,
        val previewColor: Int
    )

    data class FontStyleConfig(
        val id: String,
        val name: String,
        val banglaName: String,
        val sampleBangla: String,
        val sampleEnglish: String,
        val typeface: Typeface,
        val unicodeStyle: UnicodeFontConverter.FontStyle = UnicodeFontConverter.FontStyle.NORMAL
    )

    private val availableThemes = listOf(
        KeyboardThemeData(
            id = "dark",
            name = "iOS Dark",
            bgKeyboard = 0xFF1C1C1E.toInt(),
            bgToolbar = 0xFF2C2C2E.toInt(),
            bgSuggestion = 0xFF242426.toInt(),
            bgKeyNormal = 0xFF636366.toInt(),
            bgKeySpecial = 0xFF48484A.toInt(),
            bgKeyAccent = 0xFF0A84FF.toInt(),
            keyText = 0xFFFFFFFF.toInt(),
            previewColor = 0xFF1C1C1E.toInt()
        ),
        KeyboardThemeData(
            id = "light",
            name = "iOS Light",
            bgKeyboard = 0xFFE5E7EB.toInt(),
            bgToolbar = 0xFFF3F4F6.toInt(),
            bgSuggestion = 0xFFE5E7EB.toInt(),
            bgKeyNormal = 0xFFFFFFFF.toInt(),
            bgKeySpecial = 0xFFCBD5E1.toInt(),
            bgKeyAccent = 0xFF0A84FF.toInt(),
            keyText = 0xFF000000.toInt(),
            previewColor = 0xFFF3F4F6.toInt()
        ),
        KeyboardThemeData(
            id = "blue",
            name = "Ocean Blue",
            bgKeyboard = 0xFF0F172A.toInt(),
            bgToolbar = 0xFF1E293B.toInt(),
            bgSuggestion = 0xFF1E293B.toInt(),
            bgKeyNormal = 0xFF334155.toInt(),
            bgKeySpecial = 0xFF1E293B.toInt(),
            bgKeyAccent = 0xFF38BDF8.toInt(),
            keyText = 0xFFFFFFFF.toInt(),
            previewColor = 0xFF0F172A.toInt()
        ),
        KeyboardThemeData(
            id = "green",
            name = "Emerald Green",
            bgKeyboard = 0xFF064E3B.toInt(),
            bgToolbar = 0xFF065F46.toInt(),
            bgSuggestion = 0xFF065F46.toInt(),
            bgKeyNormal = 0xFF047857.toInt(),
            bgKeySpecial = 0xFF065F46.toInt(),
            bgKeyAccent = 0xFF34D399.toInt(),
            keyText = 0xFFECFDF5.toInt(),
            previewColor = 0xFF064E3B.toInt()
        ),
        KeyboardThemeData(
            id = "pink",
            name = "Rose Pink",
            bgKeyboard = 0xFF831843.toInt(),
            bgToolbar = 0xFF9D174D.toInt(),
            bgSuggestion = 0xFF9D174D.toInt(),
            bgKeyNormal = 0xFFBE185D.toInt(),
            bgKeySpecial = 0xFF9D174D.toInt(),
            bgKeyAccent = 0xFFF472B6.toInt(),
            keyText = 0xFFFFF1F2.toInt(),
            previewColor = 0xFF831843.toInt()
        ),
        KeyboardThemeData(
            id = "purple",
            name = "Royal Purple",
            bgKeyboard = 0xFF3B0764.toInt(),
            bgToolbar = 0xFF581C87.toInt(),
            bgSuggestion = 0xFF581C87.toInt(),
            bgKeyNormal = 0xFF7E22CE.toInt(),
            bgKeySpecial = 0xFF581C87.toInt(),
            bgKeyAccent = 0xFFC084FC.toInt(),
            keyText = 0xFFFAF5FF.toInt(),
            previewColor = 0xFF3B0764.toInt()
        )
    )

    private val availableFonts: List<FontStyleConfig> by lazy {
        listOf(
            FontStyleConfig(
                id = "default",
                name = "Modern Sans",
                banglaName = "স্ট্যান্ডার্ড সান্স",
                sampleBangla = "আমার সোনার বাংলা",
                sampleEnglish = "Modern Sans",
                typeface = Typeface.DEFAULT,
                unicodeStyle = UnicodeFontConverter.FontStyle.NORMAL
            ),
            FontStyleConfig(
                id = "serif",
                name = "Classic Serif",
                banglaName = "ঐতিহ্যবাহী সেরিফ",
                sampleBangla = "রবীন্দ্রনাথ ঠাকুর",
                sampleEnglish = "Classic Serif",
                typeface = Typeface.SERIF,
                unicodeStyle = UnicodeFontConverter.FontStyle.SERIF
            ),
            FontStyleConfig(
                id = "bold",
                name = "Bold Impact",
                banglaName = "গাঢ় বোল্ড",
                sampleBangla = "বাংলা বর্ণমালা",
                sampleEnglish = "Bold Impact",
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD),
                unicodeStyle = UnicodeFontConverter.FontStyle.BOLD
            ),
            FontStyleConfig(
                id = "monospace",
                name = "Monospace",
                banglaName = "টাইপরাইটার কোড",
                sampleBangla = "কম্পিউটার কোড",
                sampleEnglish = "Monospace 101",
                typeface = Typeface.MONOSPACE,
                unicodeStyle = UnicodeFontConverter.FontStyle.MONOSPACE
            ),
            FontStyleConfig(
                id = "script",
                name = "Cursive Script",
                banglaName = "হস্তলিপি ও কার্সিভ",
                sampleBangla = "শিল্প ও সংস্কৃতি",
                sampleEnglish = "Cursive Script",
                typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC),
                unicodeStyle = UnicodeFontConverter.FontStyle.SCRIPT
            ),
            FontStyleConfig(
                id = "rounded",
                name = "Soft Rounded",
                banglaName = "সফট রাউন্ডেড",
                sampleBangla = "সহজ সুন্দর বাংলা",
                sampleEnglish = "Soft Rounded",
                typeface = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    Typeface.create("sans-serif-rounded", Typeface.NORMAL)
                } else {
                    Typeface.SANS_SERIF
                },
                unicodeStyle = UnicodeFontConverter.FontStyle.NORMAL
            )
        )
    }

    private var currentTheme = availableThemes[0]
    private var currentFontConfig = FontStyleConfig(
        id = "default",
        name = "Modern Sans",
        banglaName = "স্ট্যান্ডার্ড সান্স",
        sampleBangla = "আমার সোনার বাংলা",
        sampleEnglish = "Modern Sans",
        typeface = Typeface.DEFAULT,
        unicodeStyle = UnicodeFontConverter.FontStyle.NORMAL
    )

    private var currentMode = KeyboardMode.BANGLA_PHONETIC
    private var isShifted = false
    private var isCapsLocked = false
    private val phoneticBuffer = StringBuilder()

    // Configurable Preferences
    private var soundEnabled = true
    private var vibrationEnabled = true
    private var vibrationStrengthMs = 15L
    private var phoneticEnabled = true
    private var keyHeightDp = 44
    private var numberRowEnabled = false

    private var vibrator: Vibrator? = null
    private var audioManager: AudioManager? = null
    private var prefs: SharedPreferences? = null

    // UI Structure
    private var rootLayout: FrameLayout? = null
    private var toolbarLayout: LinearLayout? = null
    private var suggestionContainer: LinearLayout? = null
    private var dynamicContentContainer: FrameLayout? = null

    // Sub-panels
    private var keyboardView: LinearLayout? = null
    private var emojiPanelView: View? = null
    private var themePanelView: View? = null
    private var fontStudioPanelView: View? = null
    private var stickerPanelView: View? = null
    private var clipboardPanelView: View? = null
    private var languageOverlay: FrameLayout? = null

    private var currentPanelViewMode = PanelViewMode.KEYBOARD

    // Cached Suggestion Strip Views for zero-allocation typing
    private var candidateTextView: TextView? = null
    private var rawEnglishTextView: TextView? = null
    private var statusHintTextView: TextView? = null

    // Continuous Backspace Repeat Handler
    private val repeatHandler = Handler(Looper.getMainLooper())
    private var isBackspaceRepeating = false
    private val backspaceRepeatRunnable = object : Runnable {
        override fun run() {
            if (isBackspaceRepeating) {
                performBackspace()
                repeatHandler.postDelayed(this, 45L)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, Context.MODE_PRIVATE)
        StickerManager.initDefaultStickersIfNeeded(this)
        loadPreferences()
    }

    private fun loadPreferences() {
        val sp = prefs ?: return
        val themeId = sp.getString(SettingsActivity.KEY_THEME, "dark") ?: "dark"
        currentTheme = availableThemes.find { it.id == themeId } ?: availableThemes[0]

        val fontId = sp.getString(SettingsActivity.KEY_FONT_STYLE, "default") ?: "default"
        currentFontConfig = availableFonts.find { it.id == fontId } ?: availableFonts[0]

        soundEnabled = sp.getBoolean(SettingsActivity.KEY_SOUND_ENABLED, true)
        vibrationEnabled = sp.getBoolean(SettingsActivity.KEY_VIBRATION_ENABLED, true)
        vibrationStrengthMs = when (sp.getString(SettingsActivity.KEY_VIBRATION_STRENGTH, "medium")) {
            "light" -> 10L
            "strong" -> 30L
            else -> 18L
        }
        phoneticEnabled = sp.getBoolean(SettingsActivity.KEY_PHONETIC_ENABLED, true)
        keyHeightDp = when (sp.getString(SettingsActivity.KEY_KEYBOARD_HEIGHT, "normal")) {
            "compact" -> 38
            "tall" -> 50
            else -> 44
        }
        numberRowEnabled = sp.getBoolean(SettingsActivity.KEY_NUMBER_ROW, false)

        val langPref = sp.getString(SettingsActivity.KEY_LANGUAGE, "bangla_phonetic")
        currentMode = when (langPref) {
            "bangla_unicode" -> KeyboardMode.BANGLA_UNICODE
            "english" -> KeyboardMode.ENGLISH
            else -> KeyboardMode.BANGLA_PHONETIC
        }
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        loadPreferences()
        applyCurrentTheme()
        switchPanelView(PanelViewMode.KEYBOARD)
    }

    override fun onCreateInputView(): View {
        loadPreferences()

        val root = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundColor(currentTheme.bgKeyboard)
        }
        rootLayout = root

        // Handle navigation bar window insets safely so bottom row is never hidden or pushed behind system bars
        root.setOnApplyWindowInsetsListener { view, insets ->
            val bottomInset = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                insets.getInsets(WindowInsets.Type.navigationBars()).bottom
            } else {
                @Suppress("DEPRECATION")
                insets.systemWindowInsetBottom
            }
            view.setPadding(0, 0, 0, bottomInset)
            insets
        }

        val mainColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        // 1. Gboard-inspired Toolbar (6 fully-functional tools)
        val toolbar = createToolbar()
        toolbarLayout = toolbar
        mainColumn.addView(toolbar)

        // 2. High-Performance Candidate Strip
        val sugStrip = createSuggestionStrip()
        mainColumn.addView(sugStrip)

        // 3. Dynamic Content Container (Switches between Keyboard, Emoji, Themes, Fonts, Stickers, and Clipboard)
        val contentFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        dynamicContentContainer = contentFrame

        val kbView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        keyboardView = kbView
        contentFrame.addView(kbView)
        mainColumn.addView(contentFrame)

        root.addView(mainColumn)

        // 4. In-Window Language Selection Popup Overlay
        val overlay = createLanguageMenuOverlay()
        languageOverlay = overlay
        root.addView(overlay)

        refreshKeyboardLayout()
        return root
    }

    /**
     * Toolbar with 6 tools:
     * 1. Font Style Studio ("𝔉")
     * 2. Emoji Panel ("😊")
     * 3. Sticker Studio ("🖼️")
     * 4. Clipboard Manager ("📋")
     * 5. Theme Selection ("🎨")
     * 6. Custom Settings ("⚙️")
     */
    private fun createToolbar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dpToPx(6), dpToPx(6), dpToPx(6), dpToPx(6))
            setBackgroundColor(currentTheme.bgToolbar)
            gravity = Gravity.CENTER_VERTICAL
            weightSum = 6.0f
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        // Tool 1: Font Style Studio
        bar.addView(createToolbarButton("𝔉", "Font Studio", 0xFF0A84FF.toInt()) {
            if (currentPanelViewMode == PanelViewMode.FONTS) {
                switchPanelView(PanelViewMode.KEYBOARD)
            } else {
                switchPanelView(PanelViewMode.FONTS)
            }
        })

        // Tool 2: Emoji Picker
        bar.addView(createToolbarButton("😊", "Emoji Panel", 0xFFFFD60A.toInt()) {
            if (currentPanelViewMode == PanelViewMode.EMOJI) {
                switchPanelView(PanelViewMode.KEYBOARD)
            } else {
                switchPanelView(PanelViewMode.EMOJI)
            }
        })

        // Tool 3: Sticker Studio
        bar.addView(createToolbarButton("🖼️", "Stickers", 0xFFFF375F.toInt()) {
            if (currentPanelViewMode == PanelViewMode.STICKERS) {
                switchPanelView(PanelViewMode.KEYBOARD)
            } else {
                switchPanelView(PanelViewMode.STICKERS)
            }
        })

        // Tool 4: Clipboard Manager
        bar.addView(createToolbarButton("📋", "Clipboard", 0xFF30D158.toInt()) {
            if (currentPanelViewMode == PanelViewMode.CLIPBOARD) {
                switchPanelView(PanelViewMode.KEYBOARD)
            } else {
                switchPanelView(PanelViewMode.CLIPBOARD)
            }
        })

        // Tool 5: Theme Selection Panel
        bar.addView(createToolbarButton("🎨", "Themes", 0xFF64D2FF.toInt()) {
            if (currentPanelViewMode == PanelViewMode.THEMES) {
                switchPanelView(PanelViewMode.KEYBOARD)
            } else {
                switchPanelView(PanelViewMode.THEMES)
            }
        })

        // Tool 6: Custom Settings Screen
        bar.addView(createToolbarButton("⚙️", "MBoard Settings", 0xFFFF9F0A.toInt()) {
            openSettingsActivity()
        })

        return bar
    }

    private fun createToolbarButton(
        icon: String,
        label: String,
        tintColor: Int,
        onClick: () -> Unit
    ): View {
        val frame = FrameLayout(this).apply {
            val params = LinearLayout.LayoutParams(0, dpToPx(38), 1.0f).apply {
                setMargins(dpToPx(2), 0, dpToPx(2), 0)
            }
            layoutParams = params
        }

        val btn = TextView(this).apply {
            text = icon
            contentDescription = label
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(tintColor)
            val shape = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(10).toFloat()
                setColor(0x1AFFFFFF)
            }
            background = shape
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setOnClickListener {
                provideFeedback()
                onClick()
            }
        }
        frame.addView(btn)
        return frame
    }

    /**
     * Candidate / Suggestion Strip with static pre-allocated views
     */
    private fun createSuggestionStrip(): View {
        val strip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dpToPx(10), dpToPx(4), dpToPx(10), dpToPx(4))
            setBackgroundColor(currentTheme.bgSuggestion)
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(38)
            )
        }
        suggestionContainer = strip

        candidateTextView = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 15f
            typeface = currentFontConfig.typeface
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8).toFloat()
                setColor(currentTheme.bgKeyAccent)
            }
            background = bg
            setPadding(dpToPx(12), dpToPx(4), dpToPx(12), dpToPx(4))
            visibility = View.GONE
            setOnClickListener {
                provideFeedback()
                flushPhoneticBuffer()
                currentInputConnection?.commitText(" ", 1)
            }
        }
        strip.addView(candidateTextView)

        rawEnglishTextView = TextView(this).apply {
            setTextColor(currentTheme.bgKeyAccent)
            textSize = 13f
            typeface = currentFontConfig.typeface
            setPadding(dpToPx(12), dpToPx(4), dpToPx(12), dpToPx(4))
            visibility = View.GONE
            setOnClickListener {
                provideFeedback()
                val raw = phoneticBuffer.toString()
                currentInputConnection?.commitText("$raw ", 1)
                phoneticBuffer.clear()
                updateSuggestionStrip()
            }
        }
        strip.addView(rawEnglishTextView)

        statusHintTextView = TextView(this).apply {
            setTextColor(if (currentTheme.id == "light") 0xFF64748B.toInt() else 0xFF8E8E93.toInt())
            textSize = 12f
            typeface = currentFontConfig.typeface
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            gravity = Gravity.CENTER_VERTICAL
        }
        strip.addView(statusHintTextView)

        updateSuggestionStrip()
        return strip
    }

    private fun updateSuggestionStrip() {
        val candView = candidateTextView ?: return
        val rawView = rawEnglishTextView ?: return
        val hintView = statusHintTextView ?: return

        if (currentMode == KeyboardMode.BANGLA_PHONETIC && phoneticBuffer.isNotEmpty()) {
            val bangla = BanglaPhoneticEngine.transliterate(phoneticBuffer.toString())
            candView.text = bangla
            candView.typeface = currentFontConfig.typeface
            candView.visibility = View.VISIBLE

            rawView.text = "\"${phoneticBuffer}\""
            rawView.typeface = currentFontConfig.typeface
            rawView.visibility = View.VISIBLE

            hintView.visibility = View.GONE
        } else {
            candView.visibility = View.GONE
            rawView.visibility = View.GONE

            hintView.text = when (currentMode) {
                KeyboardMode.BANGLA_PHONETIC -> "বাংলা (Avro) • Font: ${currentFontConfig.name}"
                KeyboardMode.BANGLA_UNICODE -> "বাংলা (প্রভাত) • Font: ${currentFontConfig.name}"
                KeyboardMode.ENGLISH -> "English (US) • Font: ${currentFontConfig.name}"
                else -> "MBoard Keyboard"
            }
            hintView.typeface = currentFontConfig.typeface
            hintView.visibility = View.VISIBLE
        }
    }

    /**
     * View Switcher between KEYBOARD, EMOJI, THEMES, FONTS, STICKERS, and CLIPBOARD
     */
    private fun switchPanelView(mode: PanelViewMode) {
        currentPanelViewMode = mode
        val container = dynamicContentContainer ?: return
        container.removeAllViews()

        when (mode) {
            PanelViewMode.KEYBOARD -> {
                suggestionContainer?.visibility = View.VISIBLE
                if (keyboardView == null) {
                    keyboardView = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                    }
                }
                container.addView(keyboardView)
                refreshKeyboardLayout()
            }
            PanelViewMode.EMOJI -> {
                flushPhoneticBuffer()
                suggestionContainer?.visibility = View.GONE
                emojiPanelView = createEmojiPanelView()
                container.addView(emojiPanelView)
            }
            PanelViewMode.THEMES -> {
                flushPhoneticBuffer()
                suggestionContainer?.visibility = View.GONE
                themePanelView = createThemeSelectionPanelView()
                container.addView(themePanelView)
            }
            PanelViewMode.FONTS -> {
                flushPhoneticBuffer()
                suggestionContainer?.visibility = View.GONE
                fontStudioPanelView = createFontStudioPanelView()
                container.addView(fontStudioPanelView)
            }
            PanelViewMode.STICKERS -> {
                flushPhoneticBuffer()
                suggestionContainer?.visibility = View.GONE
                stickerPanelView = createStickerStudioPanelView()
                container.addView(stickerPanelView)
            }
            PanelViewMode.CLIPBOARD -> {
                flushPhoneticBuffer()
                suggestionContainer?.visibility = View.GONE
                clipboardPanelView = createClipboardPanelView()
                container.addView(clipboardPanelView)
            }
        }
    }

    /**
     * 1. Sticker Studio Panel
     * Lists local stickers, handles InputConnectionCompat.commitContent() with clear feedback
     */
    private fun createStickerStudioPanelView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(currentTheme.bgKeyboard)
            setPadding(dpToPx(10), dpToPx(8), dpToPx(10), dpToPx(8))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(245)
            )
        }

        // Header: "🖼️ My Sticker Studio" | "+ Import" | "✓ Done"
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(8)
            }
        }

        val title = TextView(this).apply {
            text = "🖼️ My Sticker Studio"
            setTextColor(currentTheme.keyText)
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f)
        }
        header.addView(title)

        val importBtn = Button(this).apply {
            text = "+ Import"
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8).toFloat()
                setColor(0xFF059669.toInt())
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(dpToPx(80), dpToPx(32)).apply {
                rightMargin = dpToPx(6)
            }
            setOnClickListener {
                provideFeedback()
                val intent = Intent(this@MunkeyInputMethodService, StickerImportActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
            }
        }
        header.addView(importBtn)

        val doneBtn = Button(this).apply {
            text = "✓ Done"
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8).toFloat()
                setColor(currentTheme.bgKeyAccent)
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(dpToPx(75), dpToPx(32))
            setOnClickListener {
                provideFeedback()
                switchPanelView(PanelViewMode.KEYBOARD)
            }
        }
        header.addView(doneBtn)
        root.addView(header)

        // Stickers Grid
        val stickers = StickerManager.getAllStickers(this)
        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1.0f
            )
        }

        val gridLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val chunked = stickers.chunked(3)
        for (chunk in chunked) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dpToPx(68)
                ).apply {
                    bottomMargin = dpToPx(6)
                }
            }

            for (sticker in chunk) {
                val card = FrameLayout(this).apply {
                    val bg = GradientDrawable().apply {
                        cornerRadius = dpToPx(10).toFloat()
                        setColor(0x26FFFFFF)
                        setStroke(dpToPx(1), 0x33FFFFFF)
                    }
                    background = bg
                    val params = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.0f).apply {
                        setMargins(dpToPx(3), 0, dpToPx(3), 0)
                    }
                    layoutParams = params
                }

                val imageView = ImageView(this).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    ).apply {
                        setMargins(dpToPx(4), dpToPx(4), dpToPx(4), dpToPx(4))
                    }
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    try {
                        val file = File(sticker.filePath)
                        if (file.exists()) {
                            val bmp = BitmapFactory.decodeFile(file.absolutePath)
                            setImageBitmap(bmp)
                        }
                    } catch (_: Exception) {}
                }
                card.addView(imageView)

                card.setOnClickListener {
                    provideFeedback()
                    val committed = StickerManager.commitSticker(
                        this@MunkeyInputMethodService,
                        currentInputConnection,
                        currentInputEditorInfo,
                        sticker
                    )
                    if (committed) {
                        switchPanelView(PanelViewMode.KEYBOARD)
                    } else {
                        Toast.makeText(
                            this@MunkeyInputMethodService,
                            "Target app does not support rich stickers in this field",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                row.addView(card)
            }
            gridLayout.addView(row)
        }

        scrollView.addView(gridLayout)
        root.addView(scrollView)
        return root
    }

    /**
     * 2. Clipboard Manager Panel
     */
    private fun createClipboardPanelView(): View {
        ClipboardHistoryManager.syncFromSystemClipboard(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(currentTheme.bgKeyboard)
            setPadding(dpToPx(12), dpToPx(8), dpToPx(12), dpToPx(8))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(245)
            )
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(8)
            }
        }

        val title = TextView(this).apply {
            text = "📋 Clipboard Manager"
            setTextColor(currentTheme.keyText)
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f)
        }
        header.addView(title)

        val clearBtn = Button(this).apply {
            text = "Clear"
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8).toFloat()
                setColor(0xFFEF4444.toInt())
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(dpToPx(70), dpToPx(32)).apply {
                rightMargin = dpToPx(6)
            }
            setOnClickListener {
                provideFeedback()
                ClipboardHistoryManager.clearAll(this@MunkeyInputMethodService)
                switchPanelView(PanelViewMode.CLIPBOARD)
            }
        }
        header.addView(clearBtn)

        val doneBtn = Button(this).apply {
            text = "✓ Done"
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8).toFloat()
                setColor(currentTheme.bgKeyAccent)
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(dpToPx(75), dpToPx(32))
            setOnClickListener {
                provideFeedback()
                switchPanelView(PanelViewMode.KEYBOARD)
            }
        }
        header.addView(doneBtn)
        root.addView(header)

        val clips = ClipboardHistoryManager.getClips(this)
        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1.0f
            )
        }

        val listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        if (clips.isEmpty()) {
            val emptyText = TextView(this).apply {
                text = "Clipboard history is empty.\nCopied text will appear here for fast pasting."
                setTextColor(0xFF94A3B8.toInt())
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(0, dpToPx(30), 0, 0)
            }
            listContainer.addView(emptyText)
        } else {
            for (clip in clips) {
                val clipCard = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    val bg = GradientDrawable().apply {
                        cornerRadius = dpToPx(8).toFloat()
                        setColor(0x1AFFFFFF)
                        setStroke(dpToPx(1), 0x26FFFFFF)
                    }
                    background = bg
                    setPadding(dpToPx(12), dpToPx(8), dpToPx(12), dpToPx(8))
                    val params = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        bottomMargin = dpToPx(6)
                    }
                    layoutParams = params
                    setOnClickListener {
                        provideFeedback()
                        currentInputConnection?.commitText(clip.text, 1)
                        switchPanelView(PanelViewMode.KEYBOARD)
                    }
                }

                val clipText = TextView(this).apply {
                    text = clip.text
                    setTextColor(currentTheme.keyText)
                    textSize = 13f
                    maxLines = 2
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f)
                }
                clipCard.addView(clipText)

                val delBtn = TextView(this).apply {
                    text = "✕"
                    setTextColor(0xFF94A3B8.toInt())
                    textSize = 14f
                    setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4))
                    setOnClickListener {
                        provideFeedback()
                        ClipboardHistoryManager.deleteClip(this@MunkeyInputMethodService, clip.id)
                        switchPanelView(PanelViewMode.CLIPBOARD)
                    }
                }
                clipCard.addView(delBtn)

                listContainer.addView(clipCard)
            }
        }

        scrollView.addView(listContainer)
        root.addView(scrollView)
        return root
    }

    /**
     * 3. Complete Unicode Emoji Panel (9 Categories + Search)
     */
    private fun createEmojiPanelView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(currentTheme.bgKeyboard)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(245)
            )
        }

        val categories = listOf(
            "😀 Smileys" to listOf(
                "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "😊", "😇",
                "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚",
                "😋", "😛", "😜", "🤪", "😝", "🤗", "🤭", "🤫", "🤔", "🤐",
                "🤨", "😐", "😑", "😶", "😏", "😒", "🙄", "😬", "🤥", "😔",
                "😪", "🤤", "😴", "😷", "🤒", "🤕", "🤢", "🤮", "🥵", "🥶",
                "🥴", "😵", "🤯", "🤠", "🥳", "😎", "🤓", "🧐", "😕", "😟",
                "🙁", "☹️", "😮", "😯", "😲", "😳", "🥺", "😦", "😧", "😨",
                "😰", "😥", "😢", "😭", "😱", "😖", "😣", "😞", "😓", "😩",
                "😫", "🥱", "😤", "😡", "😠", "🤬", "💀", "💩", "🤡", "👻",
                "👽", "🤖", "🎃", "😺", "😸", "😹", "😻", "😼", "😽", "🙀"
            ),
            "👋 People" to listOf(
                "👋", "🤚", "🖐️", "✋", "🖖", "👌", "🤌", "🤏", "✌️", "🤞",
                "🤟", "🤘", "🤙", "👈", "👉", "👆", "🖕", "👇", "☝️", "👍",
                "👎", "✊", "👊", "🤛", "🤜", "👏", "🙌", "👐", "🤲", "🤝",
                "🙏", "✍️", "💅", "🤳", "💪", "🦵", "🦶", "👂", "👃", "🧠",
                "👀", "👁️", "👅", "👄", "💋", "👶", "👧", "👦", "👩", "👨",
                "👵", "👴", "👮", "🕵️", "💂", "👷", "🤴", "👸", "🦸", "🦹"
            ),
            "🐶 Animals" to listOf(
                "🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼", "🐨", "🐯",
                "🦁", "🐮", "🐷", "🐸", "🐵", "🐔", "🐧", "🐦", "🐤", "🦆",
                "🦅", "🦉", "🦇", "🐺", "🐗", "🐴", "🦄", "🐝", "🐛", "🦋",
                "🐌", "🐞", "🐜", "🦟", "🦗", "🕷️", "🦂", "🐢", "🐍", "🦎",
                "🐙", "🦑", "🦐", "🦞", "🦀", "🐡", "🐠", "🐟", "🐬", "🐳"
            ),
            "🍔 Food" to listOf(
                "🍏", "🍎", "🍐", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓", "🫐",
                "🍈", "🍒", "🍑", "🥭", "🍍", "🥥", "🥝", "🍅", "🥑", "🥦",
                "🌽", "🥕", "🧄", "🧅", "🥔", "🍠", "🥐", "🥯", "🍞", "🥖",
                "🧀", "🥚", "🍳", "🧈", "🥞", "🧇", "🥓", "🥩", "🍗", "🍖",
                "🍔", "🍟", "🍕", "🌭", "🥪", "🌮", "🌯", "🍿", "☕", "🍵"
            ),
            "🚀 Travel" to listOf(
                "🚗", "🚕", "🚙", "🚌", "🚎", "🏎️", "🚓", "🚑", "🚒", "🚐",
                "🛻", "🚚", "🚛", "🚜", "🛴", "🚲", "🛵", "🏍️", "🛺", "🚨",
                "🚆", "🚇", "🚈", "🚉", "🛩️", "✈️", "🛫", "🛬", "🚀", "🛸",
                "🚁", "🛶", "⛵", "🚤", "🛳️", "⛴️", "🚢", "🗺️", "🗽", "🗼"
            ),
            "⚽ Activities" to listOf(
                "⚽", "🏀", "🏈", "⚾", "🥎", "🎾", "🏐", "🏉", "🥏", "🎱",
                "🪀", "🏓", "🏸", "🏒", "🏑", "🥍", "🏏", "🪃", "🥅", "⛳",
                "🪁", "🏹", "🎣", "🤿", "🥊", "🥋", "🎽", "🛹", "🛼", "🛷",
                "⛸️", "🥌", "🎿", "⛷️", "🏂", "🪂", "🏋️", "🤼", "🤸", "🤺"
            ),
            "💡 Objects" to listOf(
                "💡", "🔦", "📱", "💻", "⌨️", "🖥️", "🖨️", "🖱️", "🎮", "🕹️",
                "🎧", "📻", "📷", "📹", "📖", "📚", "📝", "✏️", "🔑", "🗝️",
                "🔒", "🔓", "🔔", "🔕", "🎁", "🎈", "🏆", "🥇", "🥈", "🥉"
            ),
            "❤️ Symbols" to listOf(
                "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💔",
                "❣️", "💕", "💞", "💓", "💗", "💖", "💘", "💝", "💟", "☮️",
                "✝️", "☪️", "🕉️", "☸️", "✡️", "🔯", "🕎", "☯️", "☦️", "🛐",
                "♈", "♉", "♊", "♋", "♌", "♍", "♎", "♏", "♐", "♑",
                "♒", "♓", "💯", "💢", "💥", "💫", "💬", "🔴", "🟢", "🔵"
            ),
            "🚩 Flags" to listOf(
                "🇧🇩", "🏁", "🚩", "🎌", "🏴", "🏳️", "🇺🇸", "🇬🇧", "🇨🇦", "🇦🇺",
                "🇯🇵", "🇩🇪", "🇫🇷", "🇮🇹", "🇪🇸", "🇧🇷", "🇦🇷", "🇮🇳", "🇵🇰", "🇸🇦",
                "🇦🇪", "🇹🇷", "🇪🇬", "🇿🇦", "🇷🇺", "🇨🇳", "🇰🇷", "🇮🇩", "🇲🇾", "🇸🇬"
            )
        )

        var selectedCategoryIndex = 0

        val gridScrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1.0f
            )
        }

        val gridLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(6), dpToPx(6), dpToPx(6), dpToPx(6))
        }
        gridScrollView.addView(gridLayout)

        fun renderCategory(index: Int) {
            gridLayout.removeAllViews()
            val emojis = categories[index].second
            val rowSize = 7
            for (rowEmojis in emojis.chunked(rowSize)) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dpToPx(40)
                    )
                }
                for (emoji in rowEmojis) {
                    val emojiBtn = TextView(this).apply {
                        text = emoji
                        textSize = 21f
                        gravity = Gravity.CENTER
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.0f)
                        setOnClickListener {
                            provideFeedback()
                            currentInputConnection?.commitText(emoji, 1)
                        }
                    }
                    row.addView(emojiBtn)
                }
                gridLayout.addView(row)
            }
        }

        val categoryTabs = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(38)
            )
            setBackgroundColor(currentTheme.bgToolbar)
        }

        val tabsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dpToPx(4), dpToPx(2), dpToPx(4), dpToPx(2))
        }

        fun updateTabs() {
            tabsRow.removeAllViews()
            categories.forEachIndexed { idx, (catName, _) ->
                val tabBtn = TextView(this).apply {
                    text = catName
                    textSize = 12f
                    setTypeface(null, if (idx == selectedCategoryIndex) Typeface.BOLD else Typeface.NORMAL)
                    setTextColor(if (idx == selectedCategoryIndex) 0xFFFFFFFF.toInt() else 0xFF8E8E93.toInt())
                    val bg = GradientDrawable().apply {
                        cornerRadius = dpToPx(12).toFloat()
                        setColor(if (idx == selectedCategoryIndex) currentTheme.bgKeyAccent else 0x1AFFFFFF)
                    }
                    background = bg
                    setPadding(dpToPx(10), dpToPx(4), dpToPx(10), dpToPx(4))
                    val params = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        setMargins(dpToPx(3), 0, dpToPx(3), 0)
                    }
                    layoutParams = params
                    setOnClickListener {
                        provideFeedback()
                        selectedCategoryIndex = idx
                        updateTabs()
                        renderCategory(idx)
                    }
                }
                tabsRow.addView(tabBtn)
            }
        }

        categoryTabs.addView(tabsRow)
        root.addView(categoryTabs)

        renderCategory(0)
        updateTabs()
        root.addView(gridScrollView)

        // Bottom Action Bar: ABC | Space | Backspace
        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dpToPx(6), dpToPx(4), dpToPx(6), dpToPx(4))
            setBackgroundColor(currentTheme.bgToolbar)
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(44)
            )
        }

        val abcBtn = Button(this).apply {
            text = "ABC"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(currentTheme.keyText)
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8).toFloat()
                setColor(currentTheme.bgKeySpecial)
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(dpToPx(70), dpToPx(38)).apply {
                setMargins(dpToPx(4), 0, dpToPx(4), 0)
            }
            setOnClickListener {
                provideFeedback()
                switchPanelView(PanelViewMode.KEYBOARD)
            }
        }
        bottomBar.addView(abcBtn)

        val spaceBtn = Button(this).apply {
            text = "space"
            textSize = 13f
            typeface = currentFontConfig.typeface
            setTextColor(currentTheme.keyText)
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8).toFloat()
                setColor(currentTheme.bgKeyNormal)
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(0, dpToPx(38), 1.0f).apply {
                setMargins(dpToPx(4), 0, dpToPx(4), 0)
            }
            setOnClickListener {
                provideFeedback()
                currentInputConnection?.commitText(" ", 1)
            }
        }
        bottomBar.addView(spaceBtn)

        val backspaceBtn = Button(this).apply {
            text = "⌫"
            textSize = 15f
            setTextColor(currentTheme.keyText)
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8).toFloat()
                setColor(currentTheme.bgKeySpecial)
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(dpToPx(70), dpToPx(38)).apply {
                setMargins(dpToPx(4), 0, dpToPx(4), 0)
            }
            attachBackspaceTouchListener(this)
        }
        bottomBar.addView(backspaceBtn)

        root.addView(bottomBar)
        return root
    }

    /**
     * 4. Font Style Studio Panel
     */
    private fun createFontStudioPanelView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(currentTheme.bgKeyboard)
            setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(245)
            )
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(8)
            }
        }

        val title = TextView(this).apply {
            text = "𝔉 Font Style Studio • ফন্ট স্টুডিও"
            setTextColor(currentTheme.keyText)
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f)
        }
        header.addView(title)

        val doneBtn = Button(this).apply {
            text = "✓ Done"
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8).toFloat()
                setColor(currentTheme.bgKeyAccent)
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(dpToPx(75), dpToPx(32))
            setOnClickListener {
                provideFeedback()
                switchPanelView(PanelViewMode.KEYBOARD)
            }
        }
        header.addView(doneBtn)
        root.addView(header)

        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1.0f
            )
        }

        val listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        for (font in availableFonts) {
            val isSelected = font.id == currentFontConfig.id

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                val bg = GradientDrawable().apply {
                    cornerRadius = dpToPx(10).toFloat()
                    setColor(if (isSelected) 0x3338BDF8.toInt() else 0x1AFFFFFF)
                    if (isSelected) {
                        setStroke(dpToPx(2), 0xFF38BDF8.toInt())
                    } else {
                        setStroke(dpToPx(1), 0x26FFFFFF)
                    }
                }
                background = bg
                setPadding(dpToPx(12), dpToPx(8), dpToPx(12), dpToPx(8))
                val params = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = dpToPx(6)
                }
                layoutParams = params
                setOnClickListener {
                    provideFeedback()
                    applyFontStyle(font.id, save = true)
                    switchPanelView(PanelViewMode.FONTS)
                }
            }

            val topRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            val fontNameView = TextView(this).apply {
                text = "${font.name} (${font.banglaName})"
                setTextColor(currentTheme.keyText)
                textSize = 13f
                setTypeface(null, if (isSelected) Typeface.BOLD else Typeface.NORMAL)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f)
            }
            topRow.addView(fontNameView)

            if (isSelected) {
                val activeBadge = TextView(this).apply {
                    text = "✓ Active"
                    setTextColor(0xFF38BDF8.toInt())
                    textSize = 11f
                    setTypeface(null, Typeface.BOLD)
                }
                topRow.addView(activeBadge)
            }
            card.addView(topRow)

            val livePreviewView = TextView(this).apply {
                text = "${font.sampleBangla}  •  ${font.sampleEnglish}"
                setTextColor(if (isSelected) 0xFFE0F2FE.toInt() else 0xFF94A3B8.toInt())
                textSize = 14f
                typeface = font.typeface
                setPadding(0, dpToPx(4), 0, 0)
            }
            card.addView(livePreviewView)

            listContainer.addView(card)
        }

        scrollView.addView(listContainer)
        root.addView(scrollView)
        return root
    }

    fun applyFontStyle(fontId: String, save: Boolean = true) {
        val selected = availableFonts.find { it.id == fontId } ?: return
        currentFontConfig = selected
        if (save) {
            prefs?.edit()?.putString(SettingsActivity.KEY_FONT_STYLE, fontId)?.apply()
        }
        candidateTextView?.typeface = selected.typeface
        rawEnglishTextView?.typeface = selected.typeface
        statusHintTextView?.typeface = selected.typeface
        if (currentPanelViewMode == PanelViewMode.KEYBOARD) {
            refreshKeyboardLayout()
        }
    }

    /**
     * 5. Theme Selection Panel
     */
    private fun createThemeSelectionPanelView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(currentTheme.bgKeyboard)
            setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(245)
            )
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(10)
            }
        }

        val title = TextView(this).apply {
            text = "🎨 Choose Keyboard Theme"
            setTextColor(currentTheme.keyText)
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f)
        }
        header.addView(title)

        val doneBtn = Button(this).apply {
            text = "✓ Done"
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8).toFloat()
                setColor(currentTheme.bgKeyAccent)
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(dpToPx(75), dpToPx(32))
            setOnClickListener {
                provideFeedback()
                switchPanelView(PanelViewMode.KEYBOARD)
            }
        }
        header.addView(doneBtn)
        root.addView(header)

        val themesGrid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1.0f
            )
        }

        for (chunk in availableThemes.chunked(3)) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    0,
                    1.0f
                ).apply {
                    bottomMargin = dpToPx(8)
                }
            }

            for (theme in chunk) {
                val isSelected = theme.id == currentTheme.id
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    val bg = GradientDrawable().apply {
                        cornerRadius = dpToPx(12).toFloat()
                        setColor(theme.bgKeyboard)
                        if (isSelected) {
                            setStroke(dpToPx(2), 0xFF38BDF8.toInt())
                        } else {
                            setStroke(dpToPx(1), 0x33FFFFFF)
                        }
                    }
                    background = bg
                    setPadding(dpToPx(6), dpToPx(6), dpToPx(6), dpToPx(6))
                    val params = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.0f).apply {
                        setMargins(dpToPx(4), 0, dpToPx(4), 0)
                    }
                    layoutParams = params
                    setOnClickListener {
                        provideFeedback()
                        applyTheme(theme.id, save = true)
                        switchPanelView(PanelViewMode.THEMES)
                    }
                }

                val swatch = View(this).apply {
                    val dot = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(theme.bgKeyAccent)
                        setStroke(dpToPx(1), 0xFFFFFFFF.toInt())
                    }
                    background = dot
                    layoutParams = LinearLayout.LayoutParams(dpToPx(20), dpToPx(20)).apply {
                        bottomMargin = dpToPx(4)
                    }
                }
                card.addView(swatch)

                val nameView = TextView(this).apply {
                    text = theme.name
                    textSize = 11f
                    setTextColor(theme.keyText)
                    setTypeface(null, if (isSelected) Typeface.BOLD else Typeface.NORMAL)
                    gravity = Gravity.CENTER
                }
                card.addView(nameView)

                if (isSelected) {
                    val badge = TextView(this).apply {
                        text = "Active"
                        textSize = 9f
                        setTextColor(theme.bgKeyAccent)
                        setTypeface(null, Typeface.BOLD)
                    }
                    card.addView(badge)
                }

                row.addView(card)
            }
            themesGrid.addView(row)
        }

        root.addView(themesGrid)
        return root
    }

    fun applyTheme(themeId: String, save: Boolean = true) {
        val selected = availableThemes.find { it.id == themeId } ?: return
        currentTheme = selected
        if (save) {
            prefs?.edit()?.putString(SettingsActivity.KEY_THEME, themeId)?.apply()
        }
        applyCurrentTheme()
    }

    private fun applyCurrentTheme() {
        rootLayout?.setBackgroundColor(currentTheme.bgKeyboard)
        toolbarLayout?.setBackgroundColor(currentTheme.bgToolbar)
        suggestionContainer?.setBackgroundColor(currentTheme.bgSuggestion)
        candidateTextView?.apply {
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(8).toFloat()
                setColor(currentTheme.bgKeyAccent)
            }
            background = bg
        }
        rawEnglishTextView?.setTextColor(currentTheme.bgKeyAccent)
        statusHintTextView?.setTextColor(if (currentTheme.id == "light") 0xFF64748B.toInt() else 0xFF8E8E93.toInt())

        if (currentPanelViewMode == PanelViewMode.KEYBOARD) {
            refreshKeyboardLayout()
        }
    }

    private fun openSettingsActivity() {
        try {
            val intent = Intent(this, SettingsActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: Exception) {}
    }

    /**
     * 6. Keyboard Rows Rendering
     * Visibly applies active font Typeface, respects numberRow preference, and provides a separate Hide button
     */
    private fun refreshKeyboardLayout() {
        val container = keyboardView ?: return
        container.removeAllViews()

        // Dedicated Number Row (if enabled)
        if (numberRowEnabled && currentMode in listOf(KeyboardMode.ENGLISH, KeyboardMode.BANGLA_PHONETIC, KeyboardMode.BANGLA_UNICODE)) {
            val numRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            val digits = if (currentMode == KeyboardMode.BANGLA_UNICODE) {
                listOf("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০")
            } else {
                listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
            }
            for (digit in digits) {
                numRow.addView(createKeyView(digit))
            }
            container.addView(numRow)
        }

        val rows = when (currentMode) {
            KeyboardMode.ENGLISH, KeyboardMode.BANGLA_PHONETIC -> listOf(
                listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
                listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
                listOf("shift", "z", "x", "c", "v", "b", "n", "m", "backspace"),
                listOf("?123", "globe", "space", "hide", "enter")
            )
            KeyboardMode.BANGLA_UNICODE -> if (isShifted) {
                listOf(
                    listOf("অ", "আ", "ই", "ঈ", "উ", "ঊ", "ঋ", "এ", "ঐ", "ও", "ঔ"),
                    listOf("প", "ফ", "ব", "ভ", "ম", "য", "র", "ল", "শ", "ষ"),
                    listOf("shift", "স", "হ", "ড়", "ঢ়", "য়", "ৎ", "ং", "ঃ", "ঁ", "backspace"),
                    listOf("?123", "globe", "space", "hide", "enter")
                )
            } else {
                listOf(
                    listOf("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০"),
                    listOf("ক", "খ", "গ", "ঘ", "ঙ", "চ", "ছ", "জ", "ঝ", "ঞ"),
                    listOf("shift", "ট", "ঠ", "ড", "ঢ", "ণ", "ত", "থ", "দ", "ধ", "ন", "backspace"),
                    listOf("?123", "globe", "space", "hide", "enter")
                )
            }
            KeyboardMode.NUMBERS -> listOf(
                listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
                listOf("-", "/", ":", ";", "(", ")", "$", "&", "@", "\""),
                listOf("symbols", ".", ",", "?", "!", "'", "backspace"),
                listOf("ABC", "globe", "space", "hide", "enter")
            )
            KeyboardMode.SYMBOLS -> listOf(
                listOf("[", "]", "{", "}", "#", "%", "^", "*", "+", "="),
                listOf("_", "\\", "|", "~", "<", ">", "€", "£", "¥", "•"),
                listOf("numbers", ".", ",", "?", "!", "'", "backspace"),
                listOf("ABC", "globe", "space", "hide", "enter")
            )
        }

        for (row in rows) {
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            for (key in row) {
                val keyView = createKeyView(key)
                rowLayout.addView(keyView)
            }
            container.addView(rowLayout)
        }
    }

    private fun createKeyView(key: String): View {
        val isSpecial = key in listOf("shift", "backspace", "?123", "symbols", "numbers", "ABC", "globe", "hide", "enter")
        val isSpace = (key == "space")

        val btn = Button(this).apply {
            val weight = when (key) {
                "space" -> 4.0f
                "enter", "shift", "backspace" -> 1.4f
                "?123", "symbols", "numbers", "ABC" -> 1.2f
                "globe", "hide" -> 0.9f
                else -> 1.0f
            }

            val keyShape = GradientDrawable().apply {
                cornerRadius = dpToPx(8).toFloat()
                when {
                    key == "enter" -> setColor(currentTheme.bgKeyAccent)
                    isSpecial -> setColor(currentTheme.bgKeySpecial)
                    else -> setColor(currentTheme.bgKeyNormal)
                }
            }
            background = keyShape
            setTextColor(currentTheme.keyText)
            textSize = when {
                isSpace -> 12f
                isSpecial -> 13f
                else -> 17f
            }

            typeface = currentFontConfig.typeface

            text = when (key) {
                "shift" -> if (isShifted) "⬆" else "⇧"
                "backspace" -> "⌫"
                "enter" -> "↵"
                "globe" -> "🌐"
                "hide" -> "⌄"
                "space" -> getSpacebarLabel()
                else -> {
                    if (currentMode == KeyboardMode.ENGLISH) {
                        if (isShifted) key.uppercase() else key
                    } else {
                        key
                    }
                }
            }

            val params = LinearLayout.LayoutParams(0, dpToPx(keyHeightDp), weight).apply {
                setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2))
            }
            layoutParams = params

            if (key == "backspace") {
                attachBackspaceTouchListener(this)
            } else if (isSpace) {
                setOnLongClickListener {
                    provideFeedback(isLong = true)
                    showLanguageMenu()
                    true
                }
                setOnClickListener {
                    onKeyTapped("space")
                }
            } else if (key == "globe") {
                setOnClickListener {
                    provideFeedback()
                    showLanguageMenu()
                }
            } else if (key == "hide") {
                setOnClickListener {
                    provideFeedback()
                    requestHideSelf(0)
                }
            } else {
                setOnClickListener {
                    onKeyTapped(key)
                }
            }
        }
        return btn
    }

    /**
     * 7. Safe Unicode Backspace & Continuous Hold Repeat
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun attachBackspaceTouchListener(button: View) {
        button.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    isBackspaceRepeating = true
                    performBackspace()
                    repeatHandler.postDelayed(backspaceRepeatRunnable, 350L)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    isBackspaceRepeating = false
                    repeatHandler.removeCallbacks(backspaceRepeatRunnable)
                    true
                }
                else -> false
            }
        }
    }

    private fun performBackspace() {
        provideFeedback()
        val ic = currentInputConnection ?: return

        if (currentMode == KeyboardMode.BANGLA_PHONETIC && phoneticBuffer.isNotEmpty()) {
            phoneticBuffer.deleteCharAt(phoneticBuffer.length - 1)
            if (phoneticBuffer.isEmpty()) {
                ic.setComposingText("", 1)
                ic.finishComposingText()
            } else {
                val bangla = BanglaPhoneticEngine.transliterate(phoneticBuffer.toString())
                ic.setComposingText(bangla, 1)
            }
            updateSuggestionStrip()
        } else {
            val selected = ic.getSelectedText(0)
            if (!selected.isNullOrEmpty()) {
                ic.commitText("", 1)
            } else {
                val before = ic.getTextBeforeCursor(2, 0)
                if (!before.isNullOrEmpty()) {
                    val count = if (Character.isSurrogate(before.last()) && before.length >= 2) 2 else 1
                    ic.deleteSurroundingText(count, 0)
                } else {
                    ic.deleteSurroundingText(1, 0)
                }
            }
        }
    }

    private fun onKeyTapped(key: String) {
        provideFeedback()
        val ic = currentInputConnection ?: return

        when (key) {
            "shift" -> {
                isShifted = !isShifted
                refreshKeyboardLayout()
            }
            "enter" -> {
                flushPhoneticBuffer()
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
            }
            "space" -> {
                flushPhoneticBuffer()
                ic.commitText(" ", 1)
                updateSuggestionStrip()
            }
            "?123" -> {
                currentMode = KeyboardMode.NUMBERS
                refreshKeyboardLayout()
            }
            "ABC" -> {
                currentMode = KeyboardMode.ENGLISH
                refreshKeyboardLayout()
            }
            "symbols" -> {
                currentMode = KeyboardMode.SYMBOLS
                refreshKeyboardLayout()
            }
            "numbers" -> {
                currentMode = KeyboardMode.NUMBERS
                refreshKeyboardLayout()
            }
            "globe" -> {
                showLanguageMenu()
            }
            "hide" -> {
                requestHideSelf(0)
            }
            else -> {
                var charToCommit = if (isShifted && currentMode == KeyboardMode.ENGLISH) key.uppercase() else key

                if (currentMode == KeyboardMode.BANGLA_PHONETIC && phoneticEnabled) {
                    phoneticBuffer.append(charToCommit)
                    val bangla = BanglaPhoneticEngine.transliterate(phoneticBuffer.toString())
                    ic.setComposingText(bangla, 1)
                    updateSuggestionStrip()
                } else {
                    ic.commitText(charToCommit, 1)
                    if (isShifted && !isCapsLocked) {
                        isShifted = false
                        refreshKeyboardLayout()
                    }
                }
            }
        }
    }

    private fun flushPhoneticBuffer() {
        if (phoneticBuffer.isNotEmpty()) {
            val bangla = BanglaPhoneticEngine.transliterate(phoneticBuffer.toString())
            currentInputConnection?.commitText(bangla, 1)
            phoneticBuffer.clear()
        }
    }

    private fun createLanguageMenuOverlay(): FrameLayout {
        val overlay = FrameLayout(this).apply {
            setBackgroundColor(0x99000000.toInt())
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setOnClickListener {
                hideLanguageMenu()
            }
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(16).toFloat()
                setColor(currentTheme.bgToolbar)
                setStroke(dpToPx(1), 0xFF3A3A3C.toInt())
            }
            background = bg
            setPadding(dpToPx(16), dpToPx(14), dpToPx(16), dpToPx(14))
            val cardParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                setMargins(dpToPx(16), 0, dpToPx(16), dpToPx(12))
            }
            layoutParams = cardParams
            setOnClickListener { /* Consume click */ }
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(10)
            }
        }

        val title = TextView(this).apply {
            text = "🌐 Select Input Language"
            setTextColor(currentTheme.keyText)
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f)
        }
        titleRow.addView(title)

        val closeBtn = TextView(this).apply {
            text = "✕"
            setTextColor(0xFF8E8E93.toInt())
            textSize = 16f
            setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4))
            setOnClickListener {
                hideLanguageMenu()
            }
        }
        titleRow.addView(closeBtn)
        card.addView(titleRow)

        card.addView(createLanguageOptionItem(
            name = "বাংলা Phonetic (Avro-style)",
            desc = "Type English letters to output Bangla (ami -> আমি)",
            flag = "🇧🇩",
            mode = KeyboardMode.BANGLA_PHONETIC
        ))

        card.addView(createLanguageOptionItem(
            name = "বাংলা Unicode (National/Probhat)",
            desc = "Fixed Bengali keyboard layout (National)",
            flag = "🇧🇩",
            mode = KeyboardMode.BANGLA_UNICODE
        ))

        card.addView(createLanguageOptionItem(
            name = "English QWERTY",
            desc = "Standard QWERTY layout",
            flag = "🇺🇸",
            mode = KeyboardMode.ENGLISH
        ))

        overlay.addView(card)
        return overlay
    }

    private fun createLanguageOptionItem(
        name: String,
        desc: String,
        flag: String,
        mode: KeyboardMode
    ): View {
        val isSelected = (currentMode == mode)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10))
            val bg = GradientDrawable().apply {
                cornerRadius = dpToPx(10).toFloat()
                if (isSelected) {
                    setColor(currentTheme.bgKeyAccent)
                } else {
                    setColor(0x1AFFFFFF)
                }
            }
            background = bg
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(8)
            }
            layoutParams = params
            setOnClickListener {
                provideFeedback()
                selectLanguage(mode)
            }
        }

        val flagView = TextView(this).apply {
            text = flag
            textSize = 20f
            setPadding(0, 0, dpToPx(10), 0)
        }
        row.addView(flagView)

        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f)
        }

        val titleView = TextView(this).apply {
            text = name
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
        }
        textCol.addView(titleView)

        val descView = TextView(this).apply {
            text = desc
            setTextColor(if (isSelected) 0xFFD0E6FF.toInt() else 0xFF8E8E93.toInt())
            textSize = 11f
        }
        textCol.addView(descView)
        row.addView(textCol)

        if (isSelected) {
            val checkView = TextView(this).apply {
                text = "✓"
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 16f
                setTypeface(null, Typeface.BOLD)
                setPadding(dpToPx(6), 0, 0, 0)
            }
            row.addView(checkView)
        }

        return row
    }

    private fun showLanguageMenu() {
        rootLayout?.let { root ->
            languageOverlay?.let { root.removeView(it) }
            val newOverlay = createLanguageMenuOverlay()
            languageOverlay = newOverlay
            root.addView(newOverlay)
            newOverlay.visibility = View.VISIBLE
        }
    }

    private fun hideLanguageMenu() {
        languageOverlay?.visibility = View.GONE
    }

    private fun selectLanguage(newMode: KeyboardMode) {
        flushPhoneticBuffer()
        currentMode = newMode
        val langKey = when (newMode) {
            KeyboardMode.BANGLA_UNICODE -> "bangla_unicode"
            KeyboardMode.ENGLISH -> "english"
            else -> "bangla_phonetic"
        }
        prefs?.edit()?.putString(SettingsActivity.KEY_LANGUAGE, langKey)?.apply()
        hideLanguageMenu()
        refreshKeyboardLayout()
        updateSuggestionStrip()
    }

    private fun getSpacebarLabel(): String {
        return when (currentMode) {
            KeyboardMode.BANGLA_PHONETIC -> "space • বাংলা (Avro)"
            KeyboardMode.BANGLA_UNICODE -> "স্পেস • বাংলা (National)"
            KeyboardMode.ENGLISH -> "space • English (US)"
            KeyboardMode.NUMBERS, KeyboardMode.SYMBOLS -> "space"
        }
    }

    private fun provideFeedback(isLong: Boolean = false) {
        try {
            if (soundEnabled) {
                audioManager?.playSoundEffect(AudioManager.FX_KEY_CLICK)
            }
            if (vibrationEnabled) {
                val duration = if (isLong) vibrationStrengthMs * 2 else vibrationStrengthMs
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(duration)
                }
            }
        } catch (_: Exception) {}
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    override fun onDestroy() {
        super.onDestroy()
        repeatHandler.removeCallbacks(backspaceRepeatRunnable)
    }
}
