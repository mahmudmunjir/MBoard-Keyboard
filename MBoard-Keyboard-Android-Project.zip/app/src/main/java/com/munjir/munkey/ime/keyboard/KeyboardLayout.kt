package com.munjir.munkey.ime.keyboard

enum class KeyboardMode {
    ENGLISH,
    BANGLA_PHONETIC,
    BANGLA_UNICODE,
    NUMBERS,
    SYMBOLS
}

data class KeyModel(
    val primaryText: String,
    val secondaryText: String? = null,
    val code: Int = 0,
    val isAction: Boolean = false,
    val weight: Float = 1.0f
)

object KeyboardLayouts {
    val englishRows = listOf(
        listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
        listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
        listOf("shift", "z", "x", "c", "v", "b", "n", "m", "backspace"),
        listOf("?123", "globe", "space", "enter")
    )

    val banglaUnicodeRows = listOf(
        listOf("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০"),
        listOf("ক", "খ", "গ", "ঘ", "ঙ", "চ", "ছ", "জ", "ঝ", "ঞ"),
        listOf("shift", "ট", "ঠ", "ড", "ঢ", "ণ", "ত", "থ", "দ", "ধ", "ন", "backspace"),
        listOf("?123", "globe", "space", "enter")
    )

    val banglaUnicodeShiftRows = listOf(
        listOf("অ", "আ", "ই", "ঈ", "উ", "ঊ", "ঋ", "এ", "ঐ", "ও", "ঔ"),
        listOf("প", "ফ", "ব", "ভ", "ম", "য", "র", "ল", "শ", "ষ"),
        listOf("shift", "স", "হ", "ড়", "ঢ়", "য়", "ৎ", "ং", "ঃ", "ঁ", "backspace"),
        listOf("?123", "globe", "space", "enter")
    )

    val numberRows = listOf(
        listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
        listOf("-", "/", ":", ";", "(", ")", "$", "&", "@", "\""),
        listOf("symbols", ".", ",", "?", "!", "'", "backspace"),
        listOf("ABC", "globe", "space", "enter")
    )

    val symbolRows = listOf(
        listOf("[", "]", "{", "}", "#", "%", "^", "*", "+", "="),
        listOf("_", "\\", "|", "~", "<", ">", "€", "£", "¥", "•"),
        listOf("numbers", ".", ",", "?", "!", "'", "backspace"),
        listOf("ABC", "globe", "space", "enter")
    )
}
