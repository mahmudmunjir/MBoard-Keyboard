package com.munjir.munkey.ime.fontstudio

object UnicodeFontConverter {
    enum class FontStyle(val displayName: String) {
        NORMAL("Normal"), BOLD("Bold Serif"), ITALIC("Italic"), SCRIPT("Script"),
        FRAKTUR("Fraktur"), DOUBLE_STRUCK("Double-Struck"), CIRCLED("Circled"),
        SMALL_CAPS("Small Caps"), MONOSPACE("Monospace")
    }
    fun convert(text: String, style: FontStyle): String {
        if (style == FontStyle.NORMAL || text.isEmpty()) return text
        val sb = StringBuilder()
        for (c in text) {
            when (style) {
                FontStyle.BOLD -> sb.append(if (c in 'a'..'z') String(Character.toChars(0x1D41A + (c - 'a'))) else c.toString())
                FontStyle.MONOSPACE -> sb.append(if (c in 'a'..'z') String(Character.toChars(0x1D68A + (c - 'a'))) else c.toString())
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }
}
