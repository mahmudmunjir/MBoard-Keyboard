package com.munjir.munkey.ime.sticker

import android.content.ClipDescription
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

data class StickerItem(
    val id: String,
    val name: String,
    val filePath: String,
    val isCustom: Boolean = false,
    val emojiOrText: String = ""
)

object StickerManager {
    private const val PREFS_STICKERS = "mboard_stickers"
    private const val KEY_STICKER_LIST = "sticker_list_json"

    fun getStickersDir(context: Context): File {
        val dir = File(context.filesDir, "stickers")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun initDefaultStickersIfNeeded(context: Context) {
        val dir = getStickersDir(context)
        val defaultFileCheck = File(dir, "default_initialized.flag")
        if (defaultFileCheck.exists()) return

        val defaults = listOf(
            Triple("stk_1", "শুভ নববর্ষ 🌸", 0xFFFFE4E6.toInt()),
            Triple("stk_2", "ভালোবাসি 💕", 0xFFFCE7F3.toInt()),
            Triple("stk_3", "ধন্যবাদ ❤️", 0xFFFEF3C7.toInt()),
            Triple("stk_4", "স্বাগতম ✨", 0xFFEDE9FE.toInt()),
            Triple("stk_5", "চা খাবেন? ☕", 0xFFFEF9C3.toInt()),
            Triple("stk_6", "সব ঠিক আছে 👍", 0xFFDCFCE7.toInt()),
            Triple("stk_7", "ঈদ মোবারক 🌙", 0xFFE0F2FE.toInt()),
            Triple("stk_8", "Awesome! 🔥", 0xFFFFEDD5.toInt())
        )

        val items = mutableListOf<StickerItem>()
        for ((id, text, bgColor) in defaults) {
            val file = File(dir, "$id.png")
            createStickerBadgeBitmap(text, bgColor, file)
            items.add(StickerItem(id, text, file.absolutePath, false, text))
        }

        saveStickersToPrefs(context, items)
        try {
            defaultFileCheck.createNewFile()
        } catch (_: Exception) {}
    }

    private fun createStickerBadgeBitmap(text: String, bgColor: Int, destFile: File) {
        val width = 360
        val height = 240
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = bgColor
            style = Paint.Style.FILL
        }
        val rect = RectF(12f, 12f, (width - 12).toFloat(), (height - 12).toFloat())
        canvas.drawRoundRect(rect, 32f, 32f, paint)

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0x33000000
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawRoundRect(rect, 32f, 32f, borderPaint)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF1E293B.toInt()
            textSize = 34f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val yPos = (height / 2f) - ((textPaint.descent() + textPaint.ascent()) / 2f)
        canvas.drawText(text, width / 2f, yPos, textPaint)

        try {
            FileOutputStream(destFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
        } catch (_: Exception) {}
    }

    fun getAllStickers(context: Context): List<StickerItem> {
        initDefaultStickersIfNeeded(context)
        val sp = context.getSharedPreferences(PREFS_STICKERS, Context.MODE_PRIVATE)
        val jsonStr = sp.getString(KEY_STICKER_LIST, null) ?: return emptyList()
        val list = mutableListOf<StickerItem>()
        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val path = obj.getString("path")
                if (File(path).exists()) {
                    list.add(
                        StickerItem(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            filePath = path,
                            isCustom = obj.optBoolean("isCustom", false),
                            emojiOrText = obj.optString("emojiOrText", "")
                        )
                    )
                }
            }
        } catch (_: Exception) {}
        return list
    }

    fun addSticker(context: Context, name: String, bitmap: Bitmap): StickerItem? {
        val dir = getStickersDir(context)
        val id = "custom_${System.currentTimeMillis()}"
        val file = File(dir, "$id.png")
        try {
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
        } catch (_: Exception) {
            return null
        }

        val newItem = StickerItem(id, name, file.absolutePath, isCustom = true, emojiOrText = name)
        val current = getAllStickers(context).toMutableList()
        current.add(0, newItem)
        saveStickersToPrefs(context, current)
        return newItem
    }

    fun deleteSticker(context: Context, id: String): Boolean {
        val current = getAllStickers(context).toMutableList()
        val item = current.find { it.id == id } ?: return false
        try {
            File(item.filePath).delete()
        } catch (_: Exception) {}
        current.removeAll { it.id == id }
        saveStickersToPrefs(context, current)
        return true
    }

    fun clearAllCustomStickers(context: Context) {
        val current = getAllStickers(context).toMutableList()
        val remaining = mutableListOf<StickerItem>()
        for (item in current) {
            if (item.isCustom) {
                try { File(item.filePath).delete() } catch (_: Exception) {}
            } else {
                remaining.add(item)
            }
        }
        saveStickersToPrefs(context, remaining)
    }

    private fun saveStickersToPrefs(context: Context, list: List<StickerItem>) {
        val sp = context.getSharedPreferences(PREFS_STICKERS, Context.MODE_PRIVATE)
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("name", item.name)
                put("path", item.filePath)
                put("isCustom", item.isCustom)
                put("emojiOrText", item.emojiOrText)
            }
            array.put(obj)
        }
        sp.edit().putString(KEY_STICKER_LIST, array.toString()).apply()
    }

    fun isRichContentSupported(editorInfo: EditorInfo?): Boolean {
        if (editorInfo == null) return false
        val mimeTypes = EditorInfoCompat.getContentMimeTypes(editorInfo)
        return mimeTypes.any { it.startsWith("image/") || it == "*/*" }
    }

    fun commitSticker(
        context: Context,
        ic: InputConnection?,
        editorInfo: EditorInfo?,
        sticker: StickerItem
    ): Boolean {
        if (ic == null || editorInfo == null) return false
        val file = File(sticker.filePath)
        if (!file.exists()) return false

        if (!isRichContentSupported(editorInfo)) {
            return false
        }

        return try {
            val contentUri: Uri = FileProvider.getUriForFile(
                context,
                "com.munjir.munkey.fileprovider",
                file
            )
            val description = ClipDescription(sticker.name, arrayOf("image/png"))
            val contentInfo = InputContentInfoCompat(contentUri, description, null)
            val flags = InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION
            InputConnectionCompat.commitContent(ic, editorInfo, contentInfo, flags, null)
        } catch (_: Exception) {
            false
        }
    }
}
