package com.munjir.munkey.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF0F172A)) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text("MBoard Keyboard", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }) {
                        Text("1. Enable MBoard in Settings")
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                        imm?.showInputMethodPicker()
                    }) {
                        Text("2. Choose MBoard as Keyboard")
                    }
                }
            }
        }
    }
}
