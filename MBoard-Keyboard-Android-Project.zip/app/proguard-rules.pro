-keep class com.munjir.munkey.ime.** { *; }
-keepclassmembers class * extends android.inputmethodservice.InputMethodService {
    <init>(...);
}
